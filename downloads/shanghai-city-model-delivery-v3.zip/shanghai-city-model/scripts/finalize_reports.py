"""Produce current, versioned delivery notes only after all real validations pass."""
import json
from pathlib import Path
import geopandas as gpd

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs';REPORTS=OUT/'reports'
qa=json.loads((REPORTS/'qa.json').read_text());audit=json.loads((REPORTS/'overture_audit.json').read_text());roads=json.loads((REPORTS/'road_elevation_validation.json').read_text());blend=json.loads((REPORTS/'blend_readback.json').read_text())
export=next(v for v in qa['exports'] if v['file']=='model/city.glb')
assert blend['status']=='passed' and blend['mesh_objects']==export['objects']==roads['scene_objects']
assert roads['exported_mesh_transition_review_count']==0
assert qa['spatial_validation']['building_meshes_watertight']==qa['features']['buildings']['features']
path=gpd.read_file(OUT/'gis/city.gpkg',layer='road_centerlines')
path=path[path.osm_id.eq(908038897)]
assert len(path)==1 and path.length.sum()>490
for repair in audit['mesh_topology_repairs']:
    if 'removed_area_m2' in repair:repair['signed_area_delta_m2']=repair.pop('removed_area_m2')
audit['road_result']='All Overture study roads have OSM provenance. One ~498m closed running path (OSM way 908038897) was already present in current raw OSM but omitted by the prior polygon parser. Corrected and verified in city.gpkg; no invented or independent new road claimed.'
(REPORTS/'overture_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
qa['overture_audit']=audit
(REPORTS/'qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
unknown=qa['spatial_validation']['unclassified_fraction']
building_count=qa['features']['buildings']['features'];accepted=audit['accepted_rendered_footprints'];records=audit['accepted_source_ids']
for repair in audit['mesh_topology_repairs']:
    if 'removed_area_m2' in repair:repair['signed_area_delta_m2']=repair.pop('removed_area_m2')
repaired=len(audit['mesh_topology_repairs']);removed=sum(v['signed_area_delta_m2'] for v in audit['mesh_topology_repairs'])
notes=f'''# 第三版：Overture 核查与建筑补充

## 本轮实际完成

- 成功访问官方 STAC 和 Azure 数据，使用 2026-10-21.0 发布版；通过 HTTPS 字节范围和行组空间统计仅下载研究区子集，完整全球分区未下载。
- 研究区米制边界内有12023个建筑候选：1737个标注OSM来源，10286个标注东亚建筑数据集 doi:10.5281/zenodo.8174931。不同源和原始属性均保留。
- 接纳 {records} 个独立源记录，少量裁切分裂形成 {accepted} 个面片；146个高冲突候选留待核查，17个不足10m²等候选未自动建模。保留每条决策和原始几何，没有为了视觉完整而填造建筑。
- 最终地上建筑体块 {building_count} 个（原有1731个OSM体块+补充面片）。新增高度全部为低置信度估计：按已映射用地上下文使用6/8/12/15m默认值；没有实测建筑高度。
- Overture本区道路、水系仍是OSM来源，不能作为独立验证。几何对比找回约 {path.length.sum():.1f} m 的闭合跑步通道（way908038897），修复旧解析规则遗漏；道路中心线共 {qa['features']['road_centerlines']['features']} 条。
- ESA WorldCover 2021只有两个不同缩放级别的“urban”表示与本区相交，保留为参考，不把它们当作两份独立地表，也不据此臆画绿地。

## 质量核查

- {building_count} 个建筑网格闭合、正体积，体积与GIS面积×高度一致；35个GLB全部读回；28个瓦片覆盖完整边界。
- Blender工程重开确认 {blend['mesh_objects']} 个网格，与GLB一致；全域GLB {export['bytes']/1e6:.2f} MB、{export['triangles']}个三角面。
- 275个明确跨层端点的三维中心线高程验证通过；实际道路三角网连接高差超过25cm的点为0。
- 建模副本统一到1mm坐标精度，原始源几何保持不变；有符号面积差见 overture_audit.json。新轮廓中有 {repaired} 个庭院孔洞与外环单点接触，导致挤出非流形；仅在建模副本上以1cm半径打开接触点，叠加精度规范化后的有符号面积差 {removed:.6f} m²。已重新验证，不以关闭检查掩盖问题。
- 1721个同源OSM坐标摄入控制中，1720个IoU>0.9，中位数1.0。这证明摄入对齐，不等同独立实测控制。

## 仍然存在的限制

源版本中东亚建筑标记2024-11-01，影像采集日期未核实，可能有拆建变化和模型识别错误。不能声称城市现实完整性达到100%。未分类地表仍占 {unknown:.1%}，不是已确认空地。

建筑高度、部分道路/河渠宽度和树冠尺寸仍为估计。道路示意高程仍有 {roads['schematic_segments_over_20_percent']} 段坡度超过20%，最大约 {roads['maximum_schematic_centerline_slope_ratio']:.1%}，均保留QA位置；它们不是真实测得的纵坡，不能用于工程设计。没有DEM或可靠桥隧标高。

## 来源、许可与复核文件

官方Overture建筑/交通集合声明ODbL-1.0。© OpenStreetMap contributors；Overture Maps Foundation；East Asian Buildings doi:10.5281/zenodo.8174931。ESA WorldCover参考资料CC-BY-4.0。保留来源、版本、DOI、原始许可字段（上游有些为空，未擅自补造），按官方集合许可分享派生数据库，并履行署名和共享义务。

- gis/city.gpkg：最终模型GIS；每栋有source、overture_id/OSM ID、height_source、confidence。
- gis/overture_audit.gpkg：原始候选、接纳面、冲突决策以及交通/水体/地表来源子集。
- reports/overture_audit.json、overture_building_decisions.csv：数据来源、坐标对照和逐候选决策。
- reports/overture_*_download.json：实际分区URL、行组、字节范围下载统计和子集SHA-256。
- reports/road_elevation_validation.json、QA.md、qa.json：实际几何/导出/拓扑检查。

微软索引已确认无本研究区分区，没有混入其数据。此前网络阻碍已解决，本版Overture数据实际下载、核查并合并完成。此前v2成果包保留，供版本对比。
'''
updates=OUT/'更新记录.md';history=OUT/'更新记录_v2.md'
if updates.exists() and not history.exists():history.write_text(updates.read_text())
updates.write_text(notes)
(OUT/'使用说明.md').write_text(f'''# 上海城市 LOD1 第三版

先阅读 更新记录.md 和 reports/QA.md。这里是真实GIS与三维模型文件，现实完整性与高度精度仍有明确局限。

## 文件与导入

- model/city.glb：全域模型，{export['bytes']/1e6:.2f} MB，{building_count}个独立楼体；model/layers/含六类GLB，model/tiles/含28个约1公里瓦片。
- model/city.blend：Blender 4.3.2可编辑工程，各类单独Collection，已实际保存并重开验证。
- gis/city.gpkg：EPSG:32651最终GIS；gis/overture_audit.gpkg：来源与候选审计GIS。
- previews/top.png、axonometric.png、roads.png、greens.png：四张PNG。
- reports/：QA、逐候选决策、来源版本、许可、下载和坐标转换证据。

源边界WGS84由用户确认，工作投影UTM51N/EPSG:32651。模型单位米，使用共同局部原点，公式见 reports/coordinates.json。GLB采用标准Y-up，Blender导入转换为Z-up。所有分类模型/瓦片共用同一原点，组合时不要单独居中。全域与瓦片为替代选择，叠加会重复。

在支持glTF/GLB的SketchUp 2025导入器中先试一个瓦片，核对米单位、尺度与朝向。云端没有SketchUp，不能声称其原生导入已经测试；GLB已用trimesh和Blender实际读回。缺少GLB选项时使用可信glTF导入器，不要改成SKP或DAE扩展名。

## 复现

在包含data/、scripts/、outputs/的解压目录运行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r scripts/requirements-model.txt
bash scripts/run.sh
python scripts/research_sources.py
python scripts/finalize_reports.py
```

run.sh复用原始OSM缓存、研究区Overture子集和接纳候选；缺少最终GIS时先建立OSM基线，再审计补充数据并重建。Blender可用时会保存并重开工程。首次下载需访问overpass-api.de、stac.overturemaps.org、overturemapswestus2.blob.core.windows.net，均为公共读操作，无API密钥。若只有缓存，最终成果可按已保存版本复现；不要把旧缓存当作最新现实数据。

归档未携带全局分区的临时字节块缓存，保留足以复核的研究区原始GeoParquet子集、STAC元数据、URL、查询和校验值。pipeline会覆盖自己生成的outputs，不改动boundary原始文件。

## 关键限制与许可

新增建筑来自历史源轮廓，高度全部为估计；{roads['schematic_segments_over_20_percent']}段示意道路坡度异常待核实。没有实测地形或工程标高。未分类地表{unknown:.1%}不能当作真实空地，不宣称现实城市完整。

© OpenStreetMap contributors；Overture Maps Foundation；East Asian Buildings doi:10.5281/zenodo.8174931。源和派生数据库遵循官方ODbL-1.0集合许可；ESA WorldCover参考资料CC-BY-4.0。分享时保留署名和逐源版本，并履行相应许可义务。
''')
diagnosis=REPORTS/'mesh_diagnosis.json'
if diagnosis.exists():
    data=json.loads(diagnosis.read_text())
    if isinstance(data,list):diagnosis.write_text(json.dumps({'status':'historical_failures_repaired_and_revalidated','initial_failures':data,'repairs':audit['mesh_topology_repairs']},ensure_ascii=False,indent=2))
road_candidates=REPORTS/'overture_road_candidates.json'
if road_candidates.exists():
    candidates=json.loads(road_candidates.read_text())
    if isinstance(candidates,list):road_candidates.write_text(json.dumps({'baseline':'v2 model before closed-highway parser correction','status':'Resolved: current raw OSM already contained the path; current model includes way 908038897','candidates':candidates},ensure_ascii=False,indent=2))
print(json.dumps({'buildings':building_count,'supplemental_parts':accepted,'supplemental_source_ids':records,'roads':len(gpd.read_file(OUT/'gis/city.gpkg',layer='road_centerlines')),'objects':export['objects'],'model_bytes':export['bytes'],'unclassified_fraction':unknown},indent=2))
