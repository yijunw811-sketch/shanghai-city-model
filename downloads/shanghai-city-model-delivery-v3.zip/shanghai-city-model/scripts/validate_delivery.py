"""Final spatial/mesh QA, source conflicts and checksums for real deliverables."""
import hashlib
import json
from pathlib import Path
import geopandas as gpd
import numpy as np
import pandas as pd
import trimesh
from shapely.geometry import Point
from shapely.ops import unary_union

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'outputs'
qa=json.loads((OUT/'reports/qa.json').read_text())
gpkg=OUT/'gis/city.gpkg'
b=gpd.read_file(gpkg,layer='buildings');r=gpd.read_file(gpkg,layer='road_surfaces');lines=gpd.read_file(gpkg,layer='road_centerlines')
boundary=gpd.read_file(gpkg,layer='site_base').geometry.iloc[0]
building_union=unary_union(b.geometry)
ground_union=unary_union(r[r.grade==0].geometry)
assert ground_union.intersection(building_union).area<1e-6
assert ground_union.difference(boundary).area<1e-6
assert b.height_m.gt(b.min_height_m).all()
assert b.height_m.between(2,500).all()
crossings=[]
way_nodes={}
for file in (ROOT/'data/cache').glob('osm_*.json'):
    for element in json.loads(file.read_text())['elements']:
        if element['type']=='way':way_nodes[element['id']]=set(element.get('nodes',[]))
for i,j in zip(*lines.sindex.query(lines.geometry,predicate='intersects')):
    if i>=j:continue
    a=lines.iloc[i];c=lines.iloc[j]
    if a.grade!=c.grade or a.osm_id==c.osm_id:continue
    if way_nodes.get(int(a.osm_id),set()) & way_nodes.get(int(c.osm_id),set()):continue
    # Only proper interior crossings: endpoint intersections are already audited through OSM nodes.
    if not a.geometry.crosses(c.geometry):continue
    p=a.geometry.intersection(c.geometry)
    if p.geom_type=='Point':
        crossings.append({'way_a':int(a.osm_id),'way_b':int(c.osm_id),'grade':int(a.grade),'issue':'same_grade_geometric_crossing_requires_source_node_review; not automatically connected','geometry':p})
cross=gpd.GeoDataFrame(crossings or {'geometry':[]},geometry='geometry',crs=32651)
cross.to_file(gpkg,layer='road_crossing_review',driver='GPKG')
water=unary_union(gpd.read_file(gpkg,layer='water').geometry)
scene=trimesh.load(OUT/'model/city.glb',force='scene')
bm=[m for name,m in scene.geometry.items() if name.startswith('buildings_')]
assert len(bm)==len(b)
assert all(m.is_watertight and m.volume>0 for m in bm)
expected_volume=float((b.area*(b.height_m-b.min_height_m)).sum())
actual_volume=sum(m.volume for m in bm)
assert abs(actual_volume-expected_volume)/expected_volume<1e-5
tile_area=0
for tile in qa['tiles']:
    ts=trimesh.load(OUT/tile['file'],force='scene')
    area=sum(m.area for name,m in ts.geometry.items() if name.startswith('base_'))
    assert abs(area-tile['area_m2'])<max(1.,tile['area_m2']*1e-5),tile['file']
    tile_area+=tile['area_m2']
assert abs(tile_area-boundary.area)<1e-4
unclassified=gpd.read_file(gpkg,layer='unclassified_site').area.sum()
metrics={'full_boundary_base_coverage':True,'tile_area_sum_m2':tile_area,'building_meshes_watertight':len(bm),'building_volume_expected_m3':expected_volume,'building_volume_glb_m3':actual_volume,'building_overlap_source_m2':float(b.area.sum()-building_union.area),'ground_road_building_overlap_after_trim_m2':ground_union.intersection(building_union).area,'road_building_trimmed_area_m2':gpd.read_file(gpkg,layer='road_building_conflicts').area.sum(),'ground_road_water_crossing_area_m2':ground_union.intersection(water).area,'same_grade_geometric_crossings_for_review':len(cross),'unclassified_area_m2':unclassified,'unclassified_fraction':unclassified/boundary.area,'road_length_m':lines.length.sum(),'road_class_counts':lines.highway.value_counts().to_dict(),'road_length_by_class_m':lines.assign(length_m=lines.length).groupby('highway').length_m.sum().to_dict(),'validation':'PASSED for boundary coverage, exported mesh structure and IO; source completeness remains UNVERIFIED'}
qa['spatial_validation']=metrics
qa['known_limitations']+=['Overlapping source building footprints are retained for review rather than arbitrarily deleting real footprints; see spatial_validation.','Inferred ground road buffers were trimmed at building footprints, but original centerlines retained. Some resulting pinches need source verification.','Microsoft official index is accessible but contains no study-area partition. Overture independent East Asian footprints are included with per-feature provenance, historical source date and estimated heights. Roads and water have shared OSM lineage; ESA WorldCover urban polygons are reference only.','Eight roof-only features and four underground building features are excluded from above-ground solid masses, retained in building_excluded_review and original source GIS.','Waterway buffers outside mapped water polygons use conservative class width estimates; tree canopies use mapped point locations and schematic dimensions.','Road surface nominal grade elevations taper over 40m at explicit shared OSM endpoint connections. Profiles are schematic and may contain unrealistic engineering slopes; no surveyed grade is claimed.']
qa['known_limitations']=list(dict.fromkeys(qa['known_limitations']))
(OUT/'reports/qa.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'reports/spatial_validation.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
road_review=gpd.read_file(gpkg,layer='road_dangling_review').to_crs(4326)
road_review['longitude']=road_review.geometry.x;road_review['latitude']=road_review.geometry.y
road_review.drop(columns='geometry').to_csv(OUT/'reports/road_endpoints_review.csv',index=False)
summary=f'''# 上海城市 LOD1 成果与质量说明

## 已实际生成

- 边界：{boundary.area/1e6:.6f} 平方公里，WGS84（用户确认）→ EPSG:32651，局部米制坐标。
- 建筑：{len(b)} 个独立、闭合且正体积网格。高度来源：{qa['height_sources']}。
- 道路：{len(lines)} 条中心线，总长 {lines.length.sum()/1000:.2f} km；{len(r)} 条道路面记录，包含各等级已映射道路和步行通道。
- 绿地 {qa['features']['greens']['features']} 条、水系 {qa['features']['water']['features']} 条、硬质开敞场地 {qa['features']['hardscape']['features']} 条。
- 28 个约 1 km 瓦片、6 个分类 GLB、1 个全域 GLB：共 35 个 GLB 读回验证通过。
- 全域场地基底与瓦片覆盖整个边界，瓦片面积总和验证通过。建筑体积与 GIS 面积×高度一致。
- Blender 工程按建筑、道路、绿地、水体、硬质场地、基底分别组织；PNG 四张。

## 关键限制：这是有来源依据的初版，不是完整实测现状

1. 城市要素来自 OSM 与 Overture 2026-10-21.0 的东亚建筑数据集（doi:10.5281/zenodo.8174931），尚无完整独立现状清单验证现实完整性。中性未分类区域占 {unclassified/boundary.area:.1%}，不能当作“已确认空地”。微软数据无本区分区。Overture 建筑原始候选、接纳与冲突决策见 overture_audit.gpkg；保留较旧源版本，不能保证反映近期拆建。坐标摄入检查的1721个同源OSM建筑中，1720个轮廓IoU>0.9，不能等同独立测绘控制。
2. 没有实测建筑高度。{qa['height_sources'].get('type_default_estimate',0)} 栋按类型默认值估高，{qa['height_sources'].get('osm_levels_times_3m',0)} 栋按层数×3 m 估高，{qa['height_sources'].get('landuse_context_default_estimate',0)} 栋补充建筑按用地上下文采用6/8/12/15m低置信度默认值，已逐栋记录。补充轮廓不是实测高度。
3. 道路宽度含等级/车道估值。桥隧按来源 layer 分层，名义竖向采用每层 5 m；在 {qa['topology']['explicit_grade_transition_nodes']} 个边界内有明确共享 OSM 端点的跨层连接处，以 40 m 渐变衔接示意高程。已逐连接点检查高程函数一致性。匝道坡度、净空、洞口未测量，可能不符合工程坡度，不能作为工程标高。不同层级的内部几何交叉仍不自动连接。
4. 共享 OSM 节点+层级拓扑检查得到 {qa['topology']['components']} 个连通分量，内部单端节点 {qa['topology']['interior_degree1_review_count']} 个（含正常尽端路）；另有 {len(cross)} 个同层几何交叉待检查。均保留 QA GIS 图层，不虚构连接。
5. 道路推断缓冲区与建筑相交 {metrics['road_building_trimmed_area_m2']:.2f} m²，已裁除重叠面以保护建筑轮廓；原始中心线保留。道路与水面交叉 {metrics['ground_road_water_crossing_area_m2']:.2f} m²，需核实缺失桥梁标记，未凭空抬高。
6. 源建筑轮廓仍有 {metrics['building_overlap_source_m2']:.2f} m² 重叠面积（面积总和减并集）；原始轮廓保留待人工核查，避免误删真实附属建筑。
7. 已补入 31 条有来源的河渠中心线，仅在已有水面之外推断缺失水面，河宽为明确标记的保守等级估计。19 个映射树点添加示意树冠，尺寸非实测。公园/花园边界不等于每平方米都是植被，未映射道路绿带和庭院没有补画。没有 DEM，基底 z=0，非实测海拔。
8. 云端没有 SketchUp 2025，未做该软件原生导入测试；GLB 已由 trimesh 和 Blender 实际解析。未生成或伪装 SKP/DAE。
9. OSM部分剔除8个仅屋顶与4个地下要素的地上实心表达，保留1731个OSM楼体；其余来自有出处的补充轮廓。道路补回一条约498m的闭合跑步通道，其原始highway=path、leisure=track记录原已存在，旧版被面解析规则遗漏。拓扑分量195→{qa['topology']['components']}、内部单端点762→{qa['topology']['interior_degree1_review_count']}；没有为了连通性虚构道路。

## 定位与使用

所有 GLB/瓦片共用同一局部原点，组合时不要重新居中或随意移动。GLB 采用规范 Y-up（Blender 导入会转换为 Z-up），单位米。GIS 保留完整 UTM 坐标；精确恢复公式见 coordinates.json。支持 glTF/GLB 的 SketchUp 导入器中选择米单位，先导入一个瓦片核查尺寸与方向，再分批导入。若本机导入器不列出 GLB，请安装或更新可信 glTF 导入器，不要改扩展名。

详细导出对象、三角面、字节数、坐标范围、几何修复与来源见 qa.json、sources.json、overture_audit.json 和 city.gpkg。© OpenStreetMap contributors；Overture / East Asian Buildings doi:10.5281/zenodo.8174931。官方Overture建筑/交通集合声明ODbL-1.0；ESA WorldCover参考数据为CC-BY-4.0。分享派生数据库时保留署名、来源、版本并履行相应许可义务。
'''
(OUT/'reports/QA.md').write_text(summary,encoding='utf-8')
print(json.dumps(metrics,ensure_ascii=False,indent=2))
