"""Verify every GLB scene, then checksum and package reproducible outputs."""
import hashlib
import json
import shutil
from pathlib import Path
import zipfile
import trimesh
import argparse
parser=argparse.ArgumentParser();parser.add_argument('--version',default='v3');args=parser.parse_args()

ROOT=Path(__file__).resolve().parents[1]
qa_path=ROOT/'outputs/reports/qa.json'
qa=json.loads(qa_path.read_text())
for record in qa['exports']:
    scene=trimesh.load(ROOT/'outputs'/record['file'],force='scene')
    assert len(scene.geometry)==len(scene.graph.nodes_geometry)==record['objects']
    assert {scene.graph[n][1] for n in scene.graph.nodes_geometry}==set(scene.geometry)
    record['scene_references_validation']='passed'
qa_path.write_text(json.dumps(qa,ensure_ascii=False,indent=2))
blend=json.loads((ROOT/'outputs/reports/blend_readback.json').read_text())
assert blend['status']=='passed'
assert blend['mesh_objects']==next(v['objects'] for v in qa['exports'] if v['file']=='model/city.glb')
for backup in (ROOT/'outputs/model').glob('*.blend1'):backup.unlink()
files=sorted(p for directory in ['outputs','scripts','data'] for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'overture_ranges' not in p.parts and p.name not in ('SHA256SUMS.txt','package.log') and p.suffix!='.pyc')
checksum=ROOT/'outputs/SHA256SUMS.txt'
checksum.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))+'\n' for p in files))
archive=Path(f'/workspace/shanghai-city-model-delivery-{args.version}.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[checksum,ROOT/'AGENTS.md',ROOT/'README.md']:
        z.write(p,'shanghai-city-model/'+str(p.relative_to(ROOT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for line in checksum.read_text().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256(z.read('shanghai-city-model/'+name)).hexdigest()==digest,name
    count=len(z.namelist())
shutil.copy2(archive,'/workspace/shanghai-city-model-delivery.zip')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'files':count,'verified_glb_scenes':len(qa['exports']),'checksum_verification':'passed'},indent=2))
