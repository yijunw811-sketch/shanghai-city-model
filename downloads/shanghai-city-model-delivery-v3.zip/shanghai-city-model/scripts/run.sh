#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/tmp/shanghai-cache}"
export MPLCONFIGDIR="$XDG_CACHE_HOME/matplotlib"
mkdir -p "$MPLCONFIGDIR"
python scripts/fetch_osm.py
if [ ! -f outputs/gis/city.gpkg ]; then
    python scripts/build_city.py --osm-only
fi
python scripts/fetch_overture.py building segment land_cover water
python scripts/prepare_overture.py
python scripts/build_city.py
if command -v blender >/dev/null 2>&1; then
    blender --background --factory-startup --threads 4 --python scripts/blender_scene.py
    blender --background outputs/model/city.blend --threads 2 --python scripts/verify_blend.py
fi
python scripts/validate_delivery.py
python scripts/validate_roads.py
