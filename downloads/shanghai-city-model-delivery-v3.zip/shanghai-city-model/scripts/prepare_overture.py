"""Audit/merge source-grounded supplemental footprints; preserve rejected candidates."""
import json
import math
from pathlib import Path
from collections import Counter
import geopandas as gpd
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import shapely
from shapely.geometry import Polygon,LineString

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs';CACHE=ROOT/'data/cache'
boundary=gpd.read_file(ROOT/'data/boundary.geojson').to_crs(32651).geometry.iloc[0]
old_path=OUT/'gis/city.gpkg'
old=gpd.read_file(old_path,layer='buildings')
old=old[old.source.eq('OpenStreetMap')].copy()  # repeatable after a supplemental build
roads=gpd.read_file(old_path,layer='road_centerlines')
water=gpd.read_file(old_path,layer='water')
source=gpd.read_file(old_path,layer='osm_source_features')
def plain(value):
    if isinstance(value,np.ndarray):return [plain(v) for v in value]
    if isinstance(value,(list,tuple)):return [plain(v) for v in value]
    if isinstance(value,dict):return {k:plain(v) for k,v in value.items()}
    if isinstance(value,np.generic):return value.item()
    if isinstance(value,float) and not math.isfinite(value):return None
    return value
def dumps(value):return json.dumps(plain(value),ensure_ascii=False)
def polygon_parts(geometry):
    if geometry.is_empty:return []
    if isinstance(geometry,Polygon):return [geometry]
    if hasattr(geometry,'geoms'):return [p for v in geometry.geoms for p in polygon_parts(v)]
    return []
def read(kind):
    table=pq.read_table(CACHE/f'overture_{kind}_study.parquet').to_pandas()
    frame=gpd.GeoDataFrame(table.drop(columns='geometry'),geometry=shapely.from_wkb(table.geometry),crs=4326).to_crs(32651)
    frame=frame[frame.intersects(boundary)].copy()
    frame['geometry']=shapely.make_valid(frame.geometry).intersection(boundary)
    return frame[~frame.is_empty].copy()
all_data={kind:read(kind) for kind in ['building','segment','land_cover','water']}
source_gpkg=OUT/'gis/overture_audit.gpkg'
if source_gpkg.exists():source_gpkg.unlink()
for kind,data in all_data.items():
    records=[]
    for _,row in data.iterrows():
        sources=plain(row.sources)
        records.append({'overture_id':row.id,'release':'2026-10-21.0','collection_license':'ODbL-1.0','upstream_dataset':';'.join(sorted({v['dataset'] for v in sources})),'properties_json':dumps(row.drop('geometry').to_dict()),'geometry':row.geometry})
    gpd.GeoDataFrame(records,crs=32651).to_file(source_gpkg,layer=kind,driver='GPKG')

# Strong road priority: don't replace mapped roads with older inferred building pixels.
ground=roads[roads.grade==0]
mapped_water=water[~water.category.str.startswith('inferred_surface',na=False)]
raw={}
for file in CACHE.glob('osm_[01]_[01].json'):
    for element in json.loads(file.read_text())['elements']:raw[(element['type'],element['id'])]=element
track_corridors=[]
for element in raw.values():
    tags=element.get('tags',{})
    if element['type']=='way' and tags.get('highway')=='path' and tags.get('leisure')=='track':
        vertices=[(raw[('node',node)]['lon'],raw[('node',node)]['lat']) for node in element['nodes'] if ('node',node) in raw]
        if len(vertices)>1:track_corridors.append(gpd.GeoSeries([LineString(vertices)],crs=4326).to_crs(32651).iloc[0].buffer(2))
ground_buffers=[line.buffer(width/2,quad_segs=4,cap_style='round',join_style='round') for line,width in zip(ground.geometry,ground.width_m)]
mapped_road_areas=source[(source.geom_type.isin(['Polygon','MultiPolygon'])) & ((source.get('area:highway',pd.Series(index=source.index,dtype=str)).notna()) | source.get('highway',pd.Series(index=source.index,dtype=str)).eq('pedestrian'))]
mapped_road_areas=mapped_road_areas[pd.to_numeric(mapped_road_areas.get('layer',pd.Series(index=mapped_road_areas.index,dtype=str)),errors='coerce').fillna(0).eq(0)]
# Never derive the mask from already-trimmed rendered road surfaces: that would
# feed the previous supplemental footprints back into the next import.
mask=shapely.union_all(list(old.geometry)+ground_buffers+list(mapped_road_areas.geometry)+list(mapped_water.geometry)+track_corridors)
shapely.prepare(mask)
parcels=source[source.get('landuse',pd.Series(index=source.index,dtype=str)).isin(['industrial','commercial','residential','retail'])]
parcel_index=parcels.sindex
accepted=[];decisions=[];seen=set();topology_repairs=[];precision_area_delta=0.
independent=all_data['building'][all_data['building'].sources.apply(lambda ss:any(s['dataset']!='OpenStreetMap' for s in ss))]
for _,row in independent.iterrows():
    geometry=row.geometry;area=geometry.area
    has_conflict=mask.intersects(geometry)
    loss=geometry.intersection(mask).area/area if area and has_conflict else (0 if area else 1)
    decision='accept';reason='independent mapped footprint, no material conflict'
    if area<10:decision='reject';reason='clipped footprint below 10m2'
    elif bool(row.is_underground):decision='reject';reason='underground flag'
    elif loss>.10:decision='review';reason='over 10% footprint conflict with OSM building/ground road/mapped water'
    cleaned=shapely.make_valid(geometry.difference(mask)) if decision=='accept' and loss>0 else geometry
    pieces=[p for p in polygon_parts(cleaned) if p.area>=10]
    normalized=[]
    for p in pieces:
        snapped=shapely.set_precision(p,.001,mode='valid_output')
        precision_area_delta+=p.area-snapped.area
        normalized.extend(q for q in polygon_parts(snapped) if q.area>=10)
    pieces=normalized
    if decision=='accept' and not pieces:decision='reject';reason='no 10m2 polygon remains'
    context='unknown';height=12.
    if decision=='accept':
        point=geometry.representative_point()
        matches=parcels.iloc[parcel_index.query(point,predicate='intersects')]
        if len(matches):context=matches.loc[matches.area.idxmin(),'landuse']
        height={'industrial':8,'commercial':15,'residential':12,'retail':6}.get(context,12)
        for part,p in enumerate(pieces):
            touches=shapely.union_all([p.exterior.intersection(LineString(ring.coords)) for ring in p.interiors]) if p.interiors else shapely.GeometryCollection()
            if not touches.is_empty:
                original_area=p.area
                p=p.difference(touches.buffer(.01,quad_segs=4))
                assert isinstance(p,Polygon) and p.is_valid
                topology_repairs.append({'overture_id':row.id,'part':part,'action':'open_single_point_courtyard_contact_with_0_01m_radius_cut','signed_area_delta_m2':original_area-p.area,'original_geometry_retained':'overture_audit.gpkg/building and raw study parquet'})
            fingerprint=shapely.normalize(p).wkb
            if fingerprint in seen:continue
            seen.add(fingerprint)
            accepted.append({'source':'Overture / East Asian Buildings','source_date':'2024-11-01 (upstream version; imagery dates unverified)','license':'ODbL-1.0 (Overture building collection)','osm_type':None,'osm_id':None,'overture_id':row.id,'feature_id':f'overture:{row.id}:{part}','upstream_dataset':';'.join(sorted({v['dataset'] for v in plain(row.sources)})),'name':(row.names or {}).get('primary','') if isinstance(row.names,dict) else '', 'tags_json':dumps(row.drop('geometry').to_dict()),'part':part,'building':'unverified_use','height_m':height,'min_height_m':0.,'height_source':'landuse_context_default_estimate','height_explanation':f'No source height. OSM landuse context={context}; explicit default {height}m, not measurement.','confidence':'very_low','context_landuse':context,'footprint_removed_fraction':loss,'model_precision_grid_m':.001,'geometry':p})
    decisions.append({'overture_id':row.id,'decision':decision,'reason':reason,'area_m2':area,'conflict_fraction':loss,'rendered_parts':len(pieces) if decision=='accept' else 0,'height_estimate_m':height if decision=='accept' else None,'context_landuse':context,'geometry':geometry})
accepted_frame=gpd.GeoDataFrame(accepted,crs=32651)
decision_frame=gpd.GeoDataFrame(decisions,crs=32651)
accepted_frame.to_file(source_gpkg,layer='accepted_buildings',driver='GPKG')
decision_frame.to_file(source_gpkg,layer='building_decisions',driver='GPKG')
accepted_frame.to_file(CACHE/'overture_accepted_buildings.gpkg',layer='buildings',driver='GPKG')
decision_frame.drop(columns='geometry').to_csv(OUT/'reports/overture_building_decisions.csv',index=False)

# Pipeline coordinate control: OSM-derived Overture features should coincide with
# the existing OSM reference. This checks ingestion, not an independent survey.
reference={int(row.osm_id):row.geometry for _,row in old.iterrows()}
control=[]
import re
for _,row in all_data['building'].iterrows():
    for provenance in row.sources:
        if provenance['dataset']!='OpenStreetMap':continue
        match=re.match(r'w(\d+)',provenance.get('record_id') or '')
        if not match or int(match.group(1)) not in reference:continue
        a=reference[int(match.group(1))];b=row.geometry
        union=a.union(b).area
        if union:control.append(a.intersection(b).area/union)
counts={kind:len(data) for kind,data in all_data.items()}
report={'release':'2026-10-21.0','source_counts_within_projected_boundary':counts,'building_upstream_sources':dict(Counter(v['dataset'] for ss in all_data['building'].sources for v in ss)),'independent_building_candidates':len(independent),'building_decisions':decision_frame.decision.value_counts().to_dict(),'accepted_rendered_footprints':len(accepted_frame),'accepted_source_ids':accepted_frame.overture_id.nunique(),'accepted_footprint_area_m2':float(accepted_frame.area.sum()),'estimated_height_m_counts':{str(k):int(v) for k,v in accepted_frame.height_m.value_counts().items()},'coordinate_ingestion_control':{'matched_osm_ids':len(control),'median_footprint_iou':float(np.median(control)) if control else None,'iou_above_0_9':sum(v>.9 for v in control),'interpretation':'Shared-source coordinate consistency only. No independent surveyed control or imagery alignment claimed; new historical footprints retain uncertainty.'},'road_result':'All study transportation records have OSM provenance. Geometric difference identifies one ~498m closed running path already in current raw OSM; parser correction required, not an independent new road.','water_result':'All study water records have OSM provenance, not independent coverage; retain existing mapped polygons and explicit estimated widths.','land_cover_result':'Only two urban cartographic representations of ESA WorldCover 2021 intersect the site; different zoom ranges, not two independent surfaces. Retained as reference only, not reclassified as green/hardscape.','license_evidence':'Official STAC building and segment collections declare ODbL-1.0; land_cover source declares CC-BY-4.0. Preserve upstream DOI/source/version in every supplemental footprint.','height_limit':'No height values exist in downloaded buildings. Supplemental model heights are low-confidence context defaults, never measured heights.','mask_policy':'Preserve original source geometry; render only footprints with <=10% conflict with existing OSM buildings/ground roads/mapped water, trim those minor overlaps, and require >=10m2 polygon parts.'}
report['mesh_topology_repairs']=topology_repairs
report['model_coordinate_precision']={'grid_m':.001,'area_delta_m2':precision_area_delta,'original_geometry_retained':True,'reason':'Normalize submillimetre overlay fragments before float32 mesh export; use fixed original OSM centerline-width masks, not prior rendered surfaces.'}
(OUT/'reports/overture_audit.json').write_text(json.dumps(plain(report),ensure_ascii=False,indent=2))
print(json.dumps(plain(report),ensure_ascii=False,indent=2))
