"""Check official Microsoft index against every study-boundary quadkey."""
import datetime as dt
import hashlib
import json
import math
from pathlib import Path
import geopandas as gpd
import pandas as pd
import requests

ROOT=Path(__file__).resolve().parents[1]
url='https://bfppub.blob.core.windows.net/%24web/2026-08-13/dataset-links.csv'
index=ROOT/'data/cache/microsoft_dataset_links.csv'
if not index.exists():
    response=requests.get(url,timeout=90);response.raise_for_status()
    index.write_bytes(response.content)
data=pd.read_csv(index,dtype={'QuadKey':str})
boundary=gpd.read_file(ROOT/'data/boundary.geojson').geometry.iloc[0]
def tile_xy(lon,lat):
    return int((lon+180)/360*512),int((1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*512)
corners=[tile_xy(lon,lat) for lon,lat in boundary.exterior.coords]
keys=[]
for x in range(min(p[0] for p in corners),max(p[0] for p in corners)+1):
    for y in range(min(p[1] for p in corners),max(p[1] for p in corners)+1):
        keys.append(''.join(str(((x>>i)&1)+2*((y>>i)&1)) for i in range(8,-1,-1)))
matched=data[data.QuadKey.isin(keys)]
report={'checked_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'microsoft':{'index_url':url,'index_release':'2026-08-13','index_sha256':hashlib.sha256(index.read_bytes()).hexdigest(),'index_rows':len(data),'index_regions':int(data.Location.nunique()),'study_quadkeys_lod9':keys,'matching_rows':len(matched),'china_rows':int(data.Location.str.contains('China',case=False).sum()),'outcome':'no published partition for study boundary' if matched.empty else 'partition available','download_access':'index successfully downloaded after policy update','included_in_model':False,'reason':'No matching footprint partition in official index; do not fabricate coverage.'},'overture':{'discovery_url':'https://stac.overturemaps.org/catalog.json','storage_host':'overturemapswestus2.blob.core.windows.net','observed_request':'HTTP 403 policy denial on STAC catalog','status':'required domains saved to draft but not yet applied; no data downloaded or merged','coverage':'unknown; must check data and source independence before merging'},'current_supplements':{'waterways':'31 mapped source centerlines; only portions outside mapped water polygons are buffered. Class widths are explicit conservative estimates.','trees':'19 mapped source tree points with schematic canopies; no invented tree locations.','roads':'Grade transition topology/profiles derived from explicit shared OSM endpoint nodes, not invented roads.'}}
audit_path=ROOT/'outputs/reports/overture_audit.json'
if audit_path.exists():
    audit=json.loads(audit_path.read_text())
    report['overture']={'discovery_url':'https://stac.overturemaps.org/catalog.json','release':audit['release'],'storage_host':'overturemapswestus2.blob.core.windows.net','status':'STAC and Azure HTTPS range downloads succeeded; independent building footprints audited and merged','coverage':audit['source_counts_within_projected_boundary'],'accepted_rendered_footprints':audit['accepted_rendered_footprints'],'accepted_source_ids':audit['accepted_source_ids'],'source_lineage':audit['building_upstream_sources'],'license':'ODbL-1.0 per official collections; ESA WorldCover reference CC-BY-4.0','road_and_water_independence':'Both use OSM provenance in this area; no independent new road or water coverage claimed'}
    report['current_supplements']['buildings']='East Asian Buildings via Overture, with per-feature DOI/version provenance and explicit low-confidence height estimates; rejected/conflicting candidates retained in audit GIS.'
(ROOT/'outputs/reports/supplementary_sources.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
