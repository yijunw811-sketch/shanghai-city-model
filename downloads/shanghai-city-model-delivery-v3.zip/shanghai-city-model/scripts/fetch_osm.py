"""Sequential, cached Overpass acquisition with a 200 m boundary buffer."""
import datetime
import hashlib
import json
import time
from pathlib import Path
import geopandas as gpd
import requests

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / 'data/cache'
CACHE.mkdir(exist_ok=True, parents=True)
(ROOT/'outputs/reports').mkdir(exist_ok=True,parents=True)
boundary = gpd.read_file(ROOT / 'data/boundary.geojson').to_crs(32651)
buffered = gpd.GeoSeries([boundary.geometry.iloc[0].buffer(200)], crs=32651).to_crs(4326).iloc[0]
w,s,e,n = buffered.bounds
keys = ['building','building:part','highway','area:highway','landuse','natural','leisure','water','waterway','amenity','landcover','man_made']
sources = []
for iy in range(2):
    for ix in range(2):
        bbox = (s+(n-s)*iy/2, w+(e-w)*ix/2, s+(n-s)*(iy+1)/2, w+(e-w)*(ix+1)/2)
        query = '[out:json][timeout:180];(' + ''.join('nwr["'+k+'"]('+','.join(map(str,bbox))+');' for k in keys) + ');out body;>;out skel qt;'
        path = CACHE / f'osm_{iy}_{ix}.json'
        if not path.exists():
            for attempt in range(3):
                print(f'FETCH tile {iy},{ix} attempt {attempt+1}', flush=True)
                try:
                    response = requests.post('https://overpass-api.de/api/interpreter', data={'data':query}, timeout=240, headers={'User-Agent':'ShanghaiCityMassingResearch/1.0 (cached spatial research)'})
                    response.raise_for_status()
                    data = response.json()
                    if data.get('remark') or not data.get('elements'):
                        raise RuntimeError(data.get('remark','empty response'))
                    tmp = path.with_suffix('.tmp')
                    tmp.write_text(json.dumps(data), encoding='utf-8')
                    tmp.replace(path)
                    break
                except Exception as exc:
                    print(type(exc).__name__, str(exc)[:300], flush=True)
                    if attempt == 2:
                        raise
                    time.sleep(10*(attempt+1))
            time.sleep(3)
        data = json.loads(path.read_text())
        sources.append({'source':'OpenStreetMap contributors','license':'ODbL 1.0','attribution':'© OpenStreetMap contributors','url':'https://overpass-api.de/api/interpreter','bbox_s_w_n_e':bbox,'query':query,'cache':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'osm_timestamp':data.get('osm3s',{}).get('timestamp_osm_base'),'retrieved_utc':datetime.datetime.fromtimestamp(path.stat().st_mtime,datetime.timezone.utc).isoformat(),'elements':len(data['elements'])})
        print(f'OK {path.name}: {len(data["elements"])} elements', flush=True)
(ROOT/'outputs/reports/sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2))
