#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export XDG_CACHE_HOME="${XDG_CACHE_HOME:-/tmp/shanghai-cache}"
export MPLCONFIGDIR="$XDG_CACHE_HOME/matplotlib"
mkdir -p "$MPLCONFIGDIR"
python scripts/fetch_osm.py
python scripts/build_city.py
if command -v blender >/dev/null 2>&1; then
    blender --background --factory-startup --threads 4 --python scripts/blender_scene.py
    blender --background outputs/model/city.blend --threads 2 --python scripts/verify_blend.py
fi
python scripts/validate_delivery.py
python scripts/validate_roads.py
