"""Inspect exported road elevations and real scene references, not just geometry buffers."""
import json
from pathlib import Path
from collections import defaultdict
import geopandas as gpd
import numpy as np
import shapely
import trimesh

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs'
q=json.loads((OUT/'reports/qa.json').read_text());meta=q['coordinates']
scene=trimesh.load(OUT/'model/city.glb',force='scene')
assert len(scene.graph.nodes_geometry)==len(scene.geometry)
assert {scene.graph[node][1] for node in scene.graph.nodes_geometry}==set(scene.geometry)
roads=gpd.read_file(OUT/'gis/city.gpkg',layer='road_centerlines_3d')
trans=gpd.read_file(OUT/'gis/city.gpkg',layer='road_grade_transitions')
node_z=defaultdict(list);slopes=[];steep=[]
for _,row in roads.iterrows():
    xyz=np.asarray(row.geometry.coords)
    for x,y,z in xyz:node_z[(round(x,3),round(y,3),int(row.grade))].append(z)
    xy_delta=np.linalg.norm(np.diff(xyz[:,:2],axis=0),axis=1)
    for i in np.flatnonzero(xy_delta>.01):
        slope=abs(xyz[i+1,2]-xyz[i,2])/xy_delta[i];slopes.append(float(slope))
        if slope>.2:
            steep.append({'osm_id':int(row.osm_id),'highway':row.highway,'grade':int(row.grade),'slope_ratio':slope,'confidence':'schematic_height_only_not_surveyed','geometry':shapely.LineString(xyz[i:i+2])})
gpd.GeoDataFrame(steep or {'geometry':[]},geometry='geometry',crs=32651).to_file(OUT/'gis/city.gpkg',layer='road_schematic_steep_review',driver='GPKG')
line_discrepancies=[]
for _,row in trans.iterrows():
    for grade in json.loads(row.grades_json):
        heights=node_z.get((round(row.geometry.x,3),round(row.geometry.y,3),grade),[])
        if not heights or max(abs(z-row.z_target_m) for z in heights)>.01:
            line_discrepancies.append({'node':int(row.osm_node),'grade':grade,'heights':heights,'expected':row.z_target_m})
assert not line_discrepancies,line_discrepancies[:5]
by_grade=defaultdict(list)
for name,mesh in scene.geometry.items():
    if name.startswith('roads_'):
        by_grade[int(mesh.metadata['road_grade'])].append(mesh.vertices[mesh.faces])
indices={}
for grade,chunks in by_grade.items():
    triangles=np.concatenate(chunks)
    indices[grade]=(shapely.STRtree(shapely.polygons(triangles[:,:,:2])),triangles)
samples=[]
for _,row in trans.iterrows():
    xy=np.array([row.geometry.x-meta['origin_easting_m'],row.geometry.y-meta['origin_northing_m']])
    sampled=[]
    for grade in json.loads(row.grades_json):
        tree,triangles=indices[grade]
        hits=tree.query(shapely.Point(xy),predicate='intersects')
        heights=[]
        for hit in hits:
            v=triangles[hit]
            matrix=(v[:2,:2]-v[2,:2]).T
            if abs(np.linalg.det(matrix))<1e-9:continue
            weights=np.linalg.solve(matrix,xy-v[2,:2])
            heights.append(float(weights[0]*v[0,2]+weights[1]*v[1,2]+(1-weights.sum())*v[2,2]))
        sampled.append({'grade':grade,'sampled_z_m':min(heights,key=lambda z:abs(z-row.z_target_m)) if heights else None})
    heights=[v['sampled_z_m'] for v in sampled if v['sampled_z_m'] is not None]
    spread=max(heights)-min(heights) if len(heights)>1 else None
    samples.append({'osm_node':int(row.osm_node),'target_z_m':row.z_target_m,'mesh_samples':sampled,'mesh_grade_spread_m':spread,'review':len(heights)!=len(sampled) or (spread is not None and spread>.25)})
report={'scene_objects_all_referenced':True,'scene_objects':len(scene.geometry),'centerline_3d_shared_transition_validation':'passed, <=0.01m at all source shared endpoint grades','explicit_transition_nodes':len(trans),'maximum_schematic_centerline_slope_ratio':max(slopes),'schematic_segments_over_20_percent':len(steep),'exported_mesh_transition_samples':samples,'exported_mesh_transition_review_count':sum(v['review'] for v in samples),'warning':'Road elevations are estimates, not engineering grades. Mesh tessellation can leave local differences; flagged transitions must be manually checked.'}
(OUT/'reports/road_elevation_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
q['road_elevation_validation']={k:v for k,v in report.items() if k!='exported_mesh_transition_samples'}
(OUT/'reports/qa.json').write_text(json.dumps(q,ensure_ascii=False,indent=2))
qa_md=OUT/'reports/QA.md'
section='\n## 实际道路三角网验证\n'
text=qa_md.read_text().split(section)[0]
text+=section+f"\n{len(trans)} 个明确共享端点已检查三维中心线；实际 GLB 三角网连接高差超过 0.25 m 或缺少面覆盖的连接点为 {report['exported_mesh_transition_review_count']} 个。对象与场景节点逐一引用验证通过。\n\n示意高程有 {len(steep)} 段中心线坡度超过 20%，最大 {max(slopes):.1%}；这些是假设高程下的异常指标，绝非测得的真实道路坡度。GIS 图层 road_schematic_steep_review 保留位置供复核，不能用于道路纵断面设计。\n"
qa_md.write_text(text)
print(json.dumps({k:v for k,v in report.items() if k!='exported_mesh_transition_samples'},ensure_ascii=False,indent=2))
