"""Run with Blender after opening outputs/model/city.blend."""
import json
from pathlib import Path
import bpy
ROOT=Path(__file__).resolve().parents[1]
qa=json.loads((ROOT/'outputs/reports/qa.json').read_text())
expected=next(v['objects'] for v in qa['exports'] if v['file']=='model/city.glb')
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH']
assert len(meshes)==expected,(len(meshes),expected)
assert bpy.context.scene.unit_settings.scale_length==1
report={'status':'passed','mesh_objects':len(meshes),'expected_glb_objects':expected,'unit_scale':1,'collections':[c.name for c in bpy.context.scene.collection.children]}
(ROOT/'outputs/reports/blend_readback.json').write_text(json.dumps(report,indent=2))
print('BLEND_READBACK_OK',len(meshes))
