"""Import verified GLB, organize editable collections, save BLEND and render."""
import json
from pathlib import Path
import bpy
from mathutils import Vector

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(OUT/'model/city.glb'))
colors={'buildings':(.75,.75,.72,1),'roads':(.18,.19,.20,1),'greens':(.25,.43,.20,1),'water':(.22,.43,.58,1),'hardscape':(.53,.48,.40,1),'base':(.65,.63,.57,1)}
collections={}
counts={}
for category in colors:
    collection=bpy.data.collections.new(category)
    bpy.context.scene.collection.children.link(collection)
    collections[category]=collection
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH']
for obj in meshes:
    category=next((k for k in colors if obj.name.startswith(k)), 'base')
    for collection in list(obj.users_collection):collection.objects.unlink(obj)
    collections[category].objects.link(obj)
    obj.color=colors[category]
    counts[category]=counts.get(category,0)+1
    obj['category']=category
    obj['source']='OSM; see city.gpkg/qa.json for provenance'
    material=bpy.data.materials.get(category) or bpy.data.materials.new(category)
    material.diffuse_color=colors[category]
    obj.data.materials.clear();obj.data.materials.append(material)
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene['coordinate_metadata']= (OUT/'reports/coordinates.json').read_text()
scene['limitations']='OSM coverage only; inferred heights/widths; schematic bridge elevation; no DEM. See QA.'
points=[obj.matrix_world @ Vector(corner) for obj in meshes for corner in obj.bound_box]
low=Vector(tuple(min(p[i] for p in points) for i in range(3)))
high=Vector(tuple(max(p[i] for p in points) for i in range(3)))
target=(low+high)*.5
span=max(high.x-low.x,high.y-low.y)
bpy.ops.object.camera_add(location=target+Vector((span*.8,-span*1.05,span*.95)))
camera=bpy.context.object;camera.name='Axonometric camera'
camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
camera.data.type='ORTHO';camera.data.ortho_scale=span*1.42;camera.data.clip_end=span*10
scene.camera=camera
scene.render.engine='BLENDER_WORKBENCH'
scene.display.shading.light='STUDIO'
scene.display.shading.color_type='OBJECT'
scene.display.shading.show_shadows=True
scene.display.shading.show_cavity=True
scene.display.shading.cavity_type='BOTH'
scene.display.shading.background_type='WORLD'
scene.world.color=(.85,.85,.85)
scene.render.resolution_x=1800;scene.render.resolution_y=1500
scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'model/city.blend'))
scene.render.filepath=str(OUT/'previews/axonometric.png')
bpy.ops.render.render(write_still=True)
(OUT/'reports/blender.json').write_text(json.dumps({'version':bpy.app.version_string,'mesh_objects':len(meshes),'collections':counts,'bounds_local_m':[list(low),list(high)],'blend_saved':True,'axonometric_rendered':True},indent=2))
print('BLENDER_EXPORT_OK',len(meshes),counts)
