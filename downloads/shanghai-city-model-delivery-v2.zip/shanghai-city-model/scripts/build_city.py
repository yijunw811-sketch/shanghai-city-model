"""Build source-grounded, tiled LOD1 GIS/GLB. Never synthesize missing features."""
import csv
import copy
import datetime as dt
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

import geopandas as gpd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import osmnx as ox
import pandas as pd
import shapely
import trimesh
from shapely import make_valid
from shapely.affinity import translate
from shapely.geometry import Polygon, MultiPolygon, LineString, Point, box
from shapely.ops import unary_union

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs'
for name in ['gis','model/layers','model/tiles','reports','previews']:
    (OUT/name).mkdir(parents=True,exist_ok=True)
COLORS = {'buildings':'#deddd6','roads':'#545759','greens':'#739461','water':'#729db5','hardscape':'#bcb3a2','base':'#ccc8bd'}
RGBA = {k:np.array([int(v[i:i+2],16) for i in (1,3,5)]+[255],dtype=np.uint8) for k,v in COLORS.items()}
audit=[]
boundary = gpd.read_file(ROOT/'data/boundary.geojson').to_crs(32651).geometry.iloc[0]
with (ROOT/'data/boundary.csv').open(newline='') as f:
    coords=[(float(r['Longitude']),float(r['Latitude'])) for r in csv.DictReader(f)]
assert coords[0]==coords[-1] and boundary.is_valid
assert Polygon(coords).equals_exact(gpd.read_file(ROOT/'data/boundary.geojson').geometry.iloc[0],1e-10)
origin=(round(boundary.centroid.x,3),round(boundary.centroid.y,3))
metadata={'source_crs':'EPSG:4326','source_crs_evidence':'User explicitly confirmed WGS84 in task chat; no GCJ-02/BD-09 conversion applied. No independent survey control provided.','working_crs':'EPSG:32651','origin_easting_m':origin[0],'origin_northing_m':origin[1],'local_axes':'X east, Y north, Z up, metres','global_xy_formula':'UTM_X=local_X+origin_easting_m; UTM_Y=local_Y+origin_northing_m','gltf_axes':'GLB glTF convention Y-up: x=local_X,y=local_Z,z=-local_Y; nodes carry transform','z_datum':'Model reference z=0, NOT surveyed sea level. No DEM used. Boundary sample elevations not interpolated.','boundary_area_km2':boundary.area/1e6,'tile_size_m':1000,'data_timestamp_utc':dt.datetime.now(dt.timezone.utc).isoformat()}

def parts(g,kind='polygon'):
    if g is None or g.is_empty:return []
    if kind=='polygon' and isinstance(g,Polygon):return [g]
    if kind=='line' and isinstance(g,LineString):return [g]
    if hasattr(g,'geoms'):return [p for sub in g.geoms for p in parts(sub,kind)]
    return []

def clean(g,key):
    if not g.is_valid:
        audit.append({'id':str(key),'action':'make_valid','original_type':g.geom_type})
        g=make_valid(g)
    return g

def text(row,key,default=''):
    value=row.get(key,default)
    return default if value is None or (isinstance(value,float) and math.isnan(value)) else str(value)

def num(value):
    # OSM semicolon values: first positive number. Feet converted when explicit.
    m=re.search(r'[-+]?\d+(?:\.\d+)?',str(value))
    if not m:return None
    v=float(m.group())
    if 'ft' in str(value).lower() or "'" in str(value):v*=0.3048
    return v if math.isfinite(v) else None

def frame(records):
    return gpd.GeoDataFrame(records or {'geometry':[]},geometry='geometry',crs=32651)

raw={}
cache=sorted((ROOT/'data/cache').glob('osm_*.json'))
if len(cache)!=4:raise RuntimeError('Four successful source tiles required; run fetch_osm.py. Refusing to label an incomplete download as a full model.')
for file in cache:
    response=json.loads(file.read_text())
    if response.get('remark'):raise RuntimeError(response['remark'])
    for el in response['elements']:
        key=(el['type'],el['id'])
        if key not in raw or len(el.get('tags',{}))>len(raw[key].get('tags',{})):raw[key]=el
tags={k:True for k in ['building','building:part','highway','area:highway','landuse','natural','leisure','water','waterway','amenity','landcover','man_made']}
features=ox.features._create_gdf([{'elements':copy.deepcopy(list(raw.values()))}],gpd.GeoSeries([boundary.buffer(200)],crs=32651).to_crs(4326).iloc[0],tags).to_crs(32651)
features=features[features.intersects(boundary)].copy()
features['geometry']=[clean(g,k).intersection(boundary) for k,g in features.geometry.items()]
features=features[~features.geometry.is_empty]
print('Parsed features',len(features),flush=True)
source_date=max(json.loads(f.read_text()).get('osm3s',{}).get('timestamp_osm_base','') for f in cache)
def provenance(key,row):
    return {'source':'OpenStreetMap','source_date':source_date,'license':'ODbL-1.0','osm_type':str(key[0]),'osm_id':int(key[1]),'name':text(row,'name'),'tags_json':json.dumps({str(k):str(v) for k,v in row.items() if k!='geometry' and pd.notna(v)},ensure_ascii=False)}

buildings=[]; roads=[]; greens=[]; water=[]; hard=[]; roadpolys=[]; waterways=[]; trees=[]; excluded_buildings=[]; seen=set()
widths={'motorway':24,'trunk':20,'primary':16,'secondary':12,'tertiary':10,'unclassified':7,'residential':6,'living_street':5,'service':4,'footway':2,'path':1.5,'pedestrian':5,'cycleway':2.5,'steps':2,'track':3,'corridor':2,'motorway_link':7,'trunk_link':7,'primary_link':7,'secondary_link':6,'tertiary_link':5}
road_excluded={'proposed','construction','abandoned','razed','platform','bus_stop','crossing','traffic_signals','street_lamp','elevator','emergency_bay','rest_area','services'}
for key,row in features.iterrows():
    g=row.geometry; prov=provenance(key,row)
    polygon=parts(g)
    building=text(row,'building'); bp=text(row,'building:part')
    if (building not in ('','no') or bp not in ('','no')) and polygon:
        # Parent footprints take precedence; building parts retained separately in source GIS below.
        if bp not in ('','no') and not building:continue
        height=num(text(row,'height')) or num(text(row,'building:height'))
        levels=num(text(row,'building:levels'))
        hs='osm_height_tag'; confidence='medium'
        if not height or not 2<=height<=500:
            if levels and 0<levels<=120:
                height=levels*3.0; hs='osm_levels_times_3m'; confidence='medium_low'
            else:
                height={'industrial':8,'warehouse':8,'garage':3,'garages':3,'shed':3,'house':9,'detached':9,'apartments':18,'residential':12,'commercial':15,'retail':6,'office':18,'school':12,'hospital':18,'yes':12}.get(building,12)
                hs='type_default_estimate';confidence='low'
        minheight=num(text(row,'min_height')) or 0
        minheight=max(0,min(minheight,height-1))
        model_polygons=polygon
        if building=='roof' or (num(text(row,'layer')) or 0)<0 or text(row,'location')=='underground':
            reason='roof_only_not_solid_building' if building=='roof' else 'underground_building_not_above_ground_mass'
            excluded_buildings.append({**prov,'reason':reason,'geometry':g})
            audit.append({'id':str(key),'action':'exclude_from_above_ground_mass','reason':reason})
            model_polygons=[]
        for i,p in enumerate(model_polygons):
            if p.area<1:continue
            fingerprint=shapely.normalize(p).wkb
            if fingerprint in seen:
                audit.append({'id':str(key),'action':'drop_exact_duplicate_footprint'});continue
            seen.add(fingerprint)
            buildings.append({**prov,'part':i,'building':building,'height_m':height,'min_height_m':minheight,'height_source':hs,'confidence':confidence,'geometry':p})
    highway=text(row,'highway'); area_highway=text(row,'area:highway')
    if (highway and highway not in road_excluded) or area_highway:
        layer=num(text(row,'layer')) or 0
        bridge=text(row,'bridge') not in ('','no'); tunnel=text(row,'tunnel') not in ('','no')
        grade=int(layer) if layer else (1 if bridge else (-1 if tunnel else 0))
        if bridge and grade<=0:grade=1
        if tunnel and grade>=0:grade=-1
        # Vertical clearance is schematic, no surveyed deck/portal elevation is available.
        z=grade*5.0+0.12
        width=num(text(row,'width')); lanes=num(text(row,'lanes'))
        ws='osm_width_tag'
        if not width or not 0.5<=width<=80:
            width=lanes*3.25 if lanes and 0<lanes<12 else widths.get(highway,4)
            ws='lanes_times_3_25m' if lanes and 0<lanes<12 else 'class_default_estimate'
        attrs={**prov,'highway':highway or area_highway,'width_m':width,'width_source':ws,'grade':grade,'bridge':bridge,'tunnel':tunnel,'z_m':z,'z_source':'schematic_layer_times_5m','confidence':'low' if ws=='class_default_estimate' else 'medium'}
        for line in parts(g,'line'):
            if line.length<.1:continue
            roads.append({**attrs,'geometry':line})
        if polygon and (area_highway or text(row,'area')=='yes' or highway=='pedestrian'):
            for p in polygon:roadpolys.append({**attrs,'width_source':'mapped_area','geometry':p})
    lu=text(row,'landuse'); nat=text(row,'natural'); leisure=text(row,'leisure'); cover=text(row,'landcover'); amenity=text(row,'amenity')
    waterway=text(row,'waterway')
    if waterway in ('river','canal','stream','drain','ditch'):
        width=num(text(row,'width'))
        width_source='osm_width_tag'
        if not width or not .2<=width<=300:
            width={'river':12,'canal':8,'stream':3,'drain':2,'ditch':1.5}[waterway]
            width_source='waterway_class_conservative_estimate'
        for line in parts(g,'line'):
            waterways.append({**prov,'category':waterway,'width_m':width,'width_source':width_source,'confidence':'low' if 'estimate' in width_source else 'medium','geometry':line})
    if nat=='tree' and g.geom_type=='Point':
        trees.append({**prov,'height_m':num(text(row,'height')) or 6,'height_source':'osm_height_tag' if num(text(row,'height')) else 'schematic_6m','confidence':'mapped_location_unverified_canopy','geometry':g})
    if polygon:
        target=None; category=''
        if nat in ('water','wetland') or text(row,'water') or text(row,'waterway') in ('riverbank','dock') or leisure=='swimming_pool':
            target=water;category=text(row,'water') or nat or text(row,'waterway') or leisure
        elif lu in ('grass','forest','meadow','recreation_ground','village_green','allotments','orchard','plant_nursery') or nat in ('wood','grassland','scrub','heath') or leisure in ('park','garden','nature_reserve') or cover in ('grass','trees','flowerbed') or (leisure=='pitch' and text(row,'surface')=='grass'):
            target=greens;category=lu or nat or leisure or cover
        elif amenity in ('parking','marketplace') or leisure in ('pitch','playground','track','fitness_station','bleachers') or (highway=='pedestrian' and text(row,'area')=='yes'):
            target=hard;category=amenity or leisure or 'pedestrian_area'
        if target is not None:
            for p in polygon:target.append({**prov,'category':category,'confidence':'mapped_extent_not_verified_surface' if category in ('park','garden','nature_reserve') else 'mapped','geometry':p})

buildings=frame(buildings);roads=frame(roads);greens=frame(greens);water=frame(water);hard=frame(hard);mapped_roads=frame(roadpolys)
waterways=frame(waterways);trees=frame(trees)
mapped_water_union=unary_union(list(water.geometry))
inferred_water=[]
for idx,row in waterways.iterrows():
    for sub,p in enumerate(parts(row.geometry.buffer(row.width_m/2,quad_segs=4).intersection(boundary).difference(mapped_water_union))):
        if p.area>.1:
            p=p.difference(unary_union(list(buildings.geometry)))
            if not p.is_empty:inferred_water.append({**row.drop('geometry').to_dict(),'category':'inferred_surface_'+row.category,'geometry':p})
if inferred_water:water=gpd.GeoDataFrame(pd.concat([water,frame(inferred_water)],ignore_index=True),crs=32651)
# Road surfaces: planar unions per grade close true intersections without connecting bridges/tunnels.
road_surfaces=[]
grades=sorted(set(roads.get('grade',[]))|set(mapped_roads.get('grade',[])))
for grade in grades:
    group=roads[roads.grade==grade] if len(roads) else roads
    buffers=[g.buffer(w/2,cap_style='round',join_style='round',quad_segs=4) for g,w in zip(group.geometry,group.get('width_m',[]))]
    if len(mapped_roads):buffers+=list(mapped_roads[mapped_roads.grade==grade].geometry)
    united=unary_union(buffers).intersection(boundary)
    for i,p in enumerate(parts(make_valid(united))):
        if p.area>.01:road_surfaces.append({'grade':grade,'z_m':grade*5+0.12,'source':'OSM mapped areas plus inferred buffers; see road_centerlines for per-way provenance','width_source':'mixed; see road_centerlines','confidence':'inferred_width_unverified','geometry':p})
road_surfaces=frame(road_surfaces)
building_union=unary_union(list(buildings.geometry))
road_conflicts=[]
if len(road_surfaces):
    for idx,row in road_surfaces[road_surfaces.grade==0].iterrows():
        overlap=row.geometry.intersection(building_union)
        if overlap.area>.01:
            road_conflicts.append({'surface_index':int(idx),'area_m2':overlap.area,'action':'inferred_road_surface_trimmed_to_preserve_building_footprint; source_centerline_unchanged','geometry':overlap})
            road_surfaces.at[idx,'geometry']=make_valid(row.geometry.difference(building_union))
    road_surfaces=road_surfaces[~road_surfaces.is_empty].copy()
ground_roads=unary_union(list(road_surfaces[road_surfaces.grade==0].geometry)) if len(road_surfaces) else Polygon()
water_union=unary_union(list(water.geometry))
# Priority: building footprints > water > ground road > mapped greens > hardscape > unknown base.
for name,layer,mask in [('greens',greens,unary_union([building_union,ground_roads,water_union])),('hardscape',hard,unary_union([building_union,ground_roads,water_union,unary_union(list(greens.geometry))]))]:
    if len(layer):
        layer['geometry']=[make_valid(g.difference(mask)) for g in layer.geometry]
        layer.drop(layer[layer.is_empty].index,inplace=True)
base=frame([{'surface':'unclassified_neutral_reference_plane','source':'user boundary; no DEM','z_m':0.,'geometry':boundary}])
layers={'buildings':buildings,'road_centerlines':roads,'road_surfaces':road_surfaces,'greens':greens,'water':water,'hardscape':hard,'site_base':base}
layers['road_building_conflicts']=frame(road_conflicts)
layers['waterway_centerlines']=waterways
layers['mapped_trees']=trees
layers['building_excluded_review']=frame(excluded_buildings)
unclassified=boundary.difference(unary_union([building_union,ground_roads,water_union,unary_union(list(greens.geometry)),unary_union(list(hard.geometry))]))
layers['unclassified_site']=frame([{'classification':'unknown_surface_not_assumed_green','source':'boundary minus known model layers','geometry':unclassified}])

# Topology uses shared OSM node IDs and grade. Geometric crossing alone does not imply a junction.
from pyproj import Transformer
transformer=Transformer.from_crs(4326,32651,always_xy=True)
nodes={el['id']:transformer.transform(el['lon'],el['lat']) for el in raw.values() if el['type']=='node'}
graph=nx.Graph();dangling=[]
way_attrs={int(row.osm_id):(row.grade,row.highway) for _,row in roads.iterrows() if row.osm_type=='way'}
for el in raw.values():
    if el['type']!='way' or el['id'] not in way_attrs:continue
    grade,highway=way_attrs[el['id']]
    for a,b in zip(el['nodes'][:-1],el['nodes'][1:]):
        if a not in nodes or b not in nodes:continue
        segment=LineString([nodes[a],nodes[b]])
        if segment.length and segment.intersects(boundary):
            graph.add_edge((a,grade),(b,grade),osm_id=el['id'],highway=highway,length_m=segment.length)
incidence=defaultdict(list)
for el in raw.values():
    if el['type']!='way' or el['id'] not in way_attrs:continue
    grade,_=way_attrs[el['id']]
    for i,node in enumerate(el['nodes']):
        incidence[node].append((el['id'],int(grade),i in (0,len(el['nodes'])-1)))
transitions=[];transition_targets={}
for node,items in incidence.items():
    grades_here={item[1] for item in items}
    if len(grades_here)<2 or not any(item[2] for item in items):continue
    active=sorted(grade for grade in grades_here if (node,grade) in graph)
    if len(active)<2:continue
    internal_grades={item[1] for item in items if not item[2]}
    target_grade=next(iter(internal_grades)) if len(internal_grades)==1 else min(active,key=abs)
    transition_targets[node]=target_grade*5+.12
    for grade in active[1:]:
        graph.add_edge((node,active[0]),(node,grade),kind='explicit_shared_osm_endpoint_transition')
    p=Point(nodes[node])
    if boundary.covers(p):transitions.append({'osm_node':node,'grades_json':json.dumps(active),'z_target_m':transition_targets[node],'z_source':'schematic_common_elevation_at_explicit_source_connection','geometry':p})
layers['road_grade_transitions']=frame(transitions)
components=sorted(nx.connected_components(graph),key=len,reverse=True)
for node,degree in graph.degree():
    if degree!=1:continue
    p=Point(nodes[node[0]])
    if boundary.contains(p) and p.distance(boundary.boundary)>20:
        dangling.append({'osm_node':node[0],'grade':node[1],'reason':'interior_degree_1_review; cul-de-sac/access endpoints may be legitimate','geometry':p})
layers['road_dangling_review']=frame(dangling)
topology={'nodes':graph.number_of_nodes(),'edges':graph.number_of_edges(),'components':len(components),'largest_component_nodes':len(components[0]) if components else 0,'component_sizes':list(map(len,components)),'interior_degree1_review_count':len(dangling),'junction_nodes_degree_ge3':sum(d>=3 for _,d in graph.degree()),'explicit_grade_transition_nodes':len(transitions),'method':'Shared OSM node IDs, undirected connectivity. Grade changes connect only at explicit shared source nodes where at least one way ends. Different-grade interior crossings remain disconnected; no snapping or fabricated road geometry. Elevations remain schematic.','completeness':'OSM coverage only; no independent reference road inventory available. Cannot assert complete real-world coverage.'}
gpkg=OUT/'gis/city.gpkg'
if gpkg.exists():gpkg.unlink()
for name,layer in layers.items():
    # Fixed schema for empty optional layers keeps missing coverage explicit.
    layer.to_file(gpkg,layer=name,driver='GPKG')
features_out=features.copy()
for col in features_out.columns:
    if col!='geometry':features_out[col]=features_out[col].map(lambda x: str(x) if pd.notna(x) else None)
features_out.reset_index().to_file(gpkg,layer='osm_source_features',driver='GPKG')
print('Saved GIS', {k:len(v) for k,v in layers.items()},flush=True)

road_height_models={}
road_node_z={}
for grade in sorted(roads.grade.unique()):
    nominal=grade*5+.12
    subgraph=graph.subgraph([node for node in graph if node[1]==grade])
    weighted=defaultdict(float);total_weight=defaultdict(float)
    for node,target in transition_targets.items():
        key=(node,grade)
        if key not in subgraph:continue
        for other,distance in nx.single_source_dijkstra_path_length(subgraph,key,cutoff=40,weight='length_m').items():
            weight=max(0,1-distance/40.)
            weighted[other]+=weight*(target-nominal)
            total_weight[other]+=weight
    for key in subgraph:
        road_node_z[key]=transition_targets.get(key[0],nominal+weighted[key]/max(1,total_weight[key]))
for grade in sorted(roads.grade.unique()):
    models=[];used=set()
    for _,row in roads[roads.grade==grade].iterrows():
        if row.osm_id in used:continue
        used.add(row.osm_id)
        el=raw.get(('way',int(row.osm_id)))
        if el is None:continue
        available_nodes=[n for n in el['nodes'] if n in nodes]
        points=[nodes[n] for n in available_nodes]
        if len(points)<2:continue
        line=LineString(points)
        distances=np.r_[0,np.cumsum(np.linalg.norm(np.diff(np.asarray(points),axis=0),axis=1))]
        stations=[(s,road_node_z.get((n,grade),grade*5+.12)) for s,n in zip(distances,available_nodes)]
        models.append((line,stations))
    if models:road_height_models[int(grade)]=(shapely.STRtree([m[0] for m in models]),models)

def apply_road_profile(mesh,grade):
    if grade not in road_height_models:return
    tree,models=road_height_models[grade]
    xy=mesh.vertices[:,:2]+np.array(origin)
    points=shapely.points(xy)
    nearest=tree.nearest(points)
    z=np.full(len(points),grade*5+.12)
    for idx in np.unique(nearest):
        selected=np.flatnonzero(nearest==idx)
        line,stations=models[idx]
        if not stations:continue
        distances=shapely.line_locate_point(line,points[selected])
        z[selected]=np.interp(distances,[v[0] for v in stations],[v[1] for v in stations])
    mesh.vertices[:,2]=z
    mesh.metadata['road_grade']=int(grade)
    mesh.metadata['z_source']='schematic_grade_times_5m_taper_40m_to_explicit_source_connections_not_surveyed'

def insert_road_transition_vertices(mesh,grade,polygon):
    # Earcut uses boundary vertices only. Explicit interior connection vertices
    # keep the exported surface from interpolating across a junction at the wrong Z.
    vertices=np.array(mesh.vertices);faces=np.array(mesh.faces)
    for transition in transitions:
        if grade not in json.loads(transition['grades_json']):continue
        p=transition['geometry']
        if not polygon.covers(p):continue
        point=np.array([p.x-origin[0],p.y-origin[1]])
        if np.min(np.linalg.norm(vertices[:,:2]-point,axis=1))<1e-7:continue
        tri=vertices[faces,:2]
        candidates=np.flatnonzero(np.all(tri.min(axis=1)<=point+1e-8,axis=1)&np.all(tri.max(axis=1)>=point-1e-8,axis=1))
        split=[]
        for index in candidates:
            v=tri[index];matrix=(v[:2]-v[2]).T
            if abs(np.linalg.det(matrix))<1e-10:continue
            weights=np.linalg.solve(matrix,point-v[2])
            if min(weights)>=-1e-8 and weights.sum()<=1+1e-8:split.append(int(index))
        if not split:continue
        new_index=len(vertices)
        vertices=np.vstack([vertices,[point[0],point[1],grade*5+.12]])
        replacements=[]
        for index in split:
            a,b,c=faces[index]
            for first,second in [(a,b),(b,c),(c,a)]:
                v1=vertices[second,:2]-vertices[first,:2];v2=point-vertices[first,:2]
                if abs(v1[0]*v2[1]-v1[1]*v2[0])>1e-10:replacements.append([first,second,new_index])
        faces=np.vstack([np.delete(faces,split,axis=0),replacements])
    mesh.vertices=vertices;mesh.faces=faces

profile_errors=[]
for transition in transitions:
    grades_here=json.loads(transition['grades_json'])
    for grade in grades_here:
        p=transition['geometry']
        probe=trimesh.Trimesh(vertices=[[p.x-origin[0],p.y-origin[1],0]],faces=[],process=False)
        apply_road_profile(probe,grade)
        error=abs(float(probe.vertices[0,2])-transition['z_target_m'])
        if error>.001:profile_errors.append({'node':transition['osm_node'],'grade':grade,'error_m':error})
assert not profile_errors,profile_errors[:5]
metadata['road_elevation_model']='Nominal grade*5m, 40m linear taper to explicit shared source nodes. Not surveyed. road_centerlines.z_m is nominal only; 3D export below stores interpolated profile.'
metadata['explicit_grade_transition_nodes']=len(transitions)
metadata['transition_height_field_validation']='passed at all explicit shared-node transitions, tolerance 0.001m'
roads3d=roads.copy()
for idx,row in roads.iterrows():
    densified=shapely.segmentize(row.geometry,12)
    xy=np.asarray(densified.coords)[:,:2]
    vertices=np.column_stack([xy-np.array(origin),np.zeros(len(xy))])
    probe=trimesh.Trimesh(vertices=vertices,faces=[],process=False)
    apply_road_profile(probe,int(row.grade))
    roads3d.at[idx,'geometry']=LineString(np.column_stack([xy,probe.vertices[:,2]]))
roads3d['z_source']='schematic_connected_profile_not_surveyed'
roads3d.to_file(gpkg,layer='road_centerlines_3d',driver='GPKG')

# glTF is Y-up; rotate Z-up modelling frame on export, inverse on import for Blender.
UP=np.array([[1,0,0,0],[0,0,1,0],[0,-1,0,0],[0,0,0,1]],dtype=float)
def mesh_polygon(p,z,height=0):
    local=translate(p,xoff=-origin[0],yoff=-origin[1])
    if height>0:
        mesh=trimesh.creation.extrude_polygon(local,height,engine='earcut')
        mesh.apply_translation([0,0,z])
    else:
        vertices,faces=trimesh.creation.triangulate_polygon(local,engine='earcut')
        mesh=trimesh.Trimesh(vertices=np.column_stack([vertices,np.full(len(vertices),z)]),faces=faces,process=False)
    return mesh

mesh_records=[];mesh_errors=[]
def add_polys(layer,category,z):
    for idx,row in layer.iterrows():
        for sub,p in enumerate(parts(row.geometry)):
            if p.area<.01:continue
            try:
                zz=float(row.get('z_m',z))
                hh=0
                if category=='buildings':
                    zz=float(row.min_height_m)+.15;hh=float(row.height_m-row.min_height_m)
                mesh=mesh_polygon(p,zz,hh)
                if category=='roads':
                    mesh=mesh_polygon(shapely.segmentize(p,12),zz)
                    insert_road_transition_vertices(mesh,int(row.grade),p)
                    apply_road_profile(mesh,int(row.grade))
                mesh.visual=trimesh.visual.ColorVisuals(mesh,face_colors=RGBA[category])
                ident=f'{category}_{row.get("osm_id",idx)}_{idx}_{sub}'
                mesh.metadata.update({'category':category,'source_id':str(row.get('osm_id','')),'height_source':row.get('height_source',''),'z_source':mesh.metadata.get('z_source',row.get('z_source',metadata['z_datum']))})
                mesh_records.append((ident,category,mesh,p))
            except Exception as exc:
                mesh_errors.append({'layer':category,'id':str(idx),'error':str(exc)})
add_polys(base,'base',0)
add_polys(water,'water',.03)
add_polys(greens,'greens',.06)
add_polys(hard,'hardscape',.08)
add_polys(road_surfaces,'roads',.12)
add_polys(buildings,'buildings',.15)
for idx,row in trees.iterrows():
    height=max(2,min(40,float(row.height_m)))
    canopy=trimesh.creation.icosphere(subdivisions=1,radius=1)
    canopy.apply_scale([1.8,1.8,min(2.2,height*.3)])
    canopy.apply_translation([row.geometry.x-origin[0],row.geometry.y-origin[1],height-1.5])
    canopy.visual=trimesh.visual.ColorVisuals(canopy,face_colors=RGBA['greens'])
    canopy.metadata.update({'category':'greens','source_id':str(row.osm_id),'height_source':row.height_source,'symbol':'schematic canopy at mapped OSM tree location'})
    mesh_records.append((f'greens_tree_{row.osm_id}', 'greens',canopy,row.geometry))
def save_scene(records,path):
    scene=trimesh.Scene()
    assert len({r[0] for r in records})==len(records),f'Duplicate scene object names: {path}'
    for name,category,mesh,_ in records:
        scene.add_geometry(mesh,geom_name=name,node_name=name,transform=UP)
    scene.metadata=metadata
    assert len(scene.graph.nodes_geometry)==len(records),str(path)
    scene.export(path)
    return scene

scene=save_scene(mesh_records,OUT/'model/city.glb')
for category in COLORS:
    subset=[r for r in mesh_records if r[1]==category]
    if subset:save_scene(subset,OUT/f'model/layers/{category}.glb')

# Clip surfaces/building footprints per tile; same common origin, never recenter individual tiles.
minx,miny,maxx,maxy=boundary.bounds
x0=math.floor(minx/1000)*1000;y0=math.floor(miny/1000)*1000
tile_manifest=[]
for iy,y in enumerate(np.arange(y0,maxy,1000)):
    for ix,x in enumerate(np.arange(x0,maxx,1000)):
        tile=box(x,y,x+1000,y+1000).intersection(boundary)
        if tile.is_empty or tile.area<1:continue
        tile_records=[]
        for name,category,mesh,p in mesh_records:
            if not p.intersects(tile):continue
            if tile.covers(p):tile_records.append((name,category,mesh,p));continue
            clipped=make_valid(p.intersection(tile))
            for part_i,q in enumerate(parts(clipped)):
                if q.area<.01:continue
                try:
                    z=float(mesh.bounds[0,2]);height=float(mesh.extents[2]) if category=='buildings' else 0
                    clipped_mesh=mesh_polygon(q,z,height)
                    if category=='roads':
                        clipped_mesh=mesh_polygon(shapely.segmentize(q,12),z)
                        insert_road_transition_vertices(clipped_mesh,int(mesh.metadata['road_grade']),q)
                        apply_road_profile(clipped_mesh,int(mesh.metadata['road_grade']))
                    clipped_mesh.visual=trimesh.visual.ColorVisuals(clipped_mesh,face_colors=RGBA[category])
                    tile_records.append((f'{name}_clip{part_i}',category,clipped_mesh,q))
                except Exception as exc:mesh_errors.append({'layer':category,'tile':f'{ix}_{iy}','error':str(exc)})
        path=OUT/f'model/tiles/tile_{ix:02}_{iy:02}.glb'
        save_scene(tile_records,path)
        tile_manifest.append({'file':str(path.relative_to(OUT)),'area_m2':tile.area,'objects':len(tile_records),'bounds_utm':list(tile.bounds),'feature_objects_without_base':sum(r[1]!='base' for r in tile_records)})
print('Exported',len(mesh_records),'objects',len(tile_manifest),'tiles',flush=True)

validations=[]
for file in sorted((OUT/'model').rglob('*.glb')):
    check=trimesh.load(file,force='scene')
    assert len(check.geometry)>0 and np.isfinite(check.bounds).all(),str(file)
    assert len(check.graph.nodes_geometry)==len(check.geometry),str(file)
    assert {check.graph[node][1] for node in check.graph.nodes_geometry}==set(check.geometry),str(file)
    validations.append({'file':str(file.relative_to(OUT)),'bytes':file.stat().st_size,'triangles':sum(len(m.faces) for m in check.geometry.values()),'objects':len(check.geometry),'bounds_gltf':check.bounds.tolist(),'load':'passed'})
gpkg_checks={}
for name,layer in layers.items():
    loaded=gpd.read_file(gpkg,layer=name)
    assert len(loaded)==len(layer) and loaded.crs.to_epsg()==32651
    assert loaded.is_valid.all(),name
    gpkg_checks[name]={'features':len(loaded),'valid':bool(loaded.is_valid.all()),'crs':'EPSG:32651'}

def draw_map(selected,filename,title):
    fig,ax=plt.subplots(figsize=(13,10),dpi=180)
    gpd.GeoSeries([boundary],crs=32651).plot(ax=ax,color=COLORS['base'],edgecolor='#555555',linewidth=.6)
    for name,layer in selected:
        if len(layer):layer.plot(ax=ax,color=COLORS[name],linewidth=.2)
    ax.set_aspect('equal');ax.set_title(title+'\nWGS84 → UTM 51N | OSM coverage, unverified completeness',fontsize=12)
    ax.set_xlabel('UTM easting (m)');ax.set_ylabel('UTM northing (m)')
    ax.ticklabel_format(style='plain',useOffset=False)
    ax.annotate('N ↑',xy=(.96,.92),xycoords='axes fraction',ha='center')
    ax.text(.02,.02,'© OpenStreetMap contributors, ODbL 1.0 | Heights/widths include estimates',transform=ax.transAxes,fontsize=7,bbox={'facecolor':'white','alpha':.8,'edgecolor':'none'})
    fig.tight_layout();fig.savefig(OUT/f'previews/{filename}');plt.close(fig)
draw_map([('water',water),('greens',greens),('hardscape',hard),('roads',road_surfaces),('buildings',buildings)],'top.png','Shanghai LOD1 — top view')
draw_map([('roads',road_surfaces)],'roads.png','Road surfaces — includes mapped paths and inferred widths')
draw_map([('water',water),('greens',greens)],'greens.png','Mapped greens and water — unknown areas remain neutral')

height_counts=Counter(buildings.get('height_source',[]))
coverage={name:{'features':len(layer),'area_m2':float(unary_union(list(layer.geometry)).area) if name!='road_centerlines' and name!='road_dangling_review' else None} for name,layer in layers.items()}
report={'status':'source_grounded_model_with_documented_limitations','coordinates':metadata,'features':coverage,'height_sources':dict(height_counts),'height_range_m':[float(buildings.height_m.min()),float(buildings.height_m.max())] if len(buildings) else [],'road_width_sources':dict(Counter(roads.get('width_source',[]))),'road_grade_counts':dict(Counter(map(str,roads.get('grade',[])))),'topology':topology,'tiles':tile_manifest,'empty_feature_tiles':sum(t['feature_objects_without_base']==0 for t in tile_manifest),'mesh_errors':mesh_errors,'geometry_audit':audit,'exports':validations,'gpkg_validation':gpkg_checks,'known_limitations':['Only OSM is available; real-world feature completeness not independently established. Missing unmapped private/access roads cannot be invented.','Building heights tagged in OSM are source attributes, not verified measurements; default/levels estimates recorded per footprint.','Road width defaults and layer*5m vertical separation are schematic. Ramp slopes, bridge clearance and tunnel portals are not surveyed. No fabricated connectors.','Mapped parks/gardens indicate mapped site extents, not verified vegetation coverage. Unmapped road medians/courtyards remain unclassified.','No DEM: flat reference base at z=0; not an absolute vertical datum.','SketchUp application is unavailable in cloud; every GLB parsed but native SketchUp import not tested.','GCJ-02/BD-09 cannot be diagnosed from a standalone rectangle; WGS84 used based on user confirmation.','Building parts are retained in source GIS but parent footprint LOD1 used to avoid double-volume overlap.']}
(OUT/'reports/qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'reports/coordinates.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'reports/QA.md').write_text('# 上海城市 LOD1 自动生产 QA\n\n'+f'边界：{boundary.area/1e6:.6f} km²；建筑 {len(buildings)}；道路中心线 {len(roads)}；绿地 {len(greens)}；水系 {len(water)}；瓦片 {len(tile_manifest)}。\n\n'+'详细指标与全部 GLB 读回验证见 qa.json。源数据许可、下载时间、查询和校验值见 sources.json。\n\n## 不能据此宣称完整实测模型\n\n'+'\n'.join('- '+x for x in report['known_limitations'])+'\n',encoding='utf-8')
assert not mesh_errors, f'Mesh export errors: {len(mesh_errors)}; inspect QA'
print('QA passed:',len(validations),'GLB files reloaded; GIS layers reloaded',flush=True)
