Dataset: Air Quality Dataset for Shanghai

Dataset: Air Quality Dataset for Shanghai provides historical air quality time series for Shanghai. It includes city metadata such as coordinates, administrative areas, and population. You can use this dataset to track long-run air quality changes, compare Shanghai with other cities, and create city-level models using air quality signals.

Files included:
- city_info.csv contains identifiers, coordinates, and population.
- air_quality_historical.csv contains the historical time series.
