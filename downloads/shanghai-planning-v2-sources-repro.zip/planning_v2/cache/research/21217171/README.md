# Processed grid-level data for bird-related sentiment and environmental variables in Shanghai, 2022–2024

This repository contains processed and anonymized data prepared to support the manuscript entitled "Spatial patterns of the bird-related sentiment index and its nonlinear environmental associations: Evidence from social media and explainable machine learning".

## Files

- `processed_grid_sentiment_environment_data.csv`: final 500 m × 500 m occupied-grid analytical dataset. It includes 1280 grid cells with at least one valid spatially matched bird-related Weibo comment, the grid-level bird-related sentiment index, comment counts, and grid-level environmental variables.
- `grid_sentiment_summary_2022_2024.csv`: cleaned grid-level sentiment summary derived from the ArcGIS spatial join and summary statistics. The unmatched row with blank `grid_id` was excluded.
- `grid_id_reference.csv`: reference information for occupied grid cells, including grid ID, district, town/subdistrict name, grid area, and comment count.
- `anonymized_comment_sentiment_scores.csv`: anonymized comment-level sentiment scores containing only sequential comment IDs, posting year, and model-generated sentiment scores. This file does not contain raw text, user identifiers, Weibo IDs, exact coordinates, precise timestamps, post URLs, or profile information.
- `metadata_data_dictionary.csv`: variable definitions, units, data sources, and processing descriptions.
- `public_data_sources.csv`: links and descriptions for publicly available environmental and spatial datasets.

## Spatial matching summary

The original cleaned dataset contained 4,142 valid bird-related Weibo check-in comments from 2022 to 2024. Among them, 4,011 comments were successfully assigned to the 500 m × 500 m grid system. The remaining 131 comments were not included in grid-based statistics because they did not match the final analytical grid after boundary and water-area processing. The final occupied-grid dataset contains 1280 grid cells.

## Data restrictions

Raw Weibo data are not included because they are subject to Weibo platform terms of service and may contain potentially identifiable user-generated information. The original post text, user identifiers, Weibo IDs, exact geotagged coordinates, precise timestamps, user profile information, and post URLs have been excluded.

The shared grid-level dataset is aggregated and processed for analysis and does not contain raw user-level text records.

## Code availability

This repository contains processed/anonymized data and metadata only. Analysis code is not included in this data deposit.
