<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" simplifyLocal="1" minScale="100000000" simplifyMaxScale="1" autoRefreshMode="Disabled" autoRefreshTime="0" simplifyDrawingTol="1" labelsEnabled="0" readOnly="0" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" maxScale="0" simplifyAlgorithm="0" symbologyReferenceScale="-1" version="3.40.6-Bratislava">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal enabled="0" durationField="" limitMode="0" mode="0" fixedDuration="0" startField="" startExpression="" durationUnit="min" endField="" accumulate="0" endExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation clamping="Terrain" symbology="Line" showMarkerSymbolInSurfacePlots="0" zscale="1" type="IndividualFeatures" extrusionEnabled="0" zoffset="0" binding="Centroid" extrusion="0" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" type="line" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{06009331-9611-43b4-b252-580a8a7e26d3}" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="57,178,91,255,hsv:0.38055555555555554,0.67843137254901964,0.69803921568627447,1" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{f4ea58e7-a75a-41ed-8026-9ee075992fe7}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="57,178,91,255,hsv:0.38055555555555554,0.67843137254901964,0.69803921568627447,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="41,127,65,255,hsv:0.38055555555555554,0.67843137254901964,0.49858854047455559,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" type="marker" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{13b878eb-0106-406f-a918-6b4246ce32c4}" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="57,178,91,255,hsv:0.38055555555555554,0.67843137254901964,0.69803921568627447,1" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="41,127,65,255,hsv:0.38055555555555554,0.67843137254901964,0.49858854047455559,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="singleSymbol" forceraster="0" referencescale="-1" symbollevels="0">
    <symbols>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{ee4504ba-bb09-41bf-bd7c-81295813a416}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="145,176,148,255,rgb:0.56862745098039214,0.69019607843137254,0.58039215686274515,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="no" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option value="" type="QString"/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="provider">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dataset">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source_url">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="retrieved_at">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="release_date">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="license">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="crs_original">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="processing_steps">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="is_inferred">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="evidence">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="confidence">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="spatial_accuracy_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="canonical_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_type">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="snapshot_date">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="access">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags_json">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="green_type">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="interpretation">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="in_aoi">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="fid" name=""/>
    <alias index="1" field="provider" name=""/>
    <alias index="2" field="dataset" name=""/>
    <alias index="3" field="source_url" name=""/>
    <alias index="4" field="retrieved_at" name=""/>
    <alias index="5" field="release_date" name=""/>
    <alias index="6" field="license" name=""/>
    <alias index="7" field="crs_original" name=""/>
    <alias index="8" field="processing_steps" name=""/>
    <alias index="9" field="is_inferred" name=""/>
    <alias index="10" field="evidence" name=""/>
    <alias index="11" field="confidence" name=""/>
    <alias index="12" field="spatial_accuracy_m" name=""/>
    <alias index="13" field="canonical_id" name=""/>
    <alias index="14" field="osm_type" name=""/>
    <alias index="15" field="osm_id" name=""/>
    <alias index="16" field="snapshot_date" name=""/>
    <alias index="17" field="name" name=""/>
    <alias index="18" field="access" name=""/>
    <alias index="19" field="tags_json" name=""/>
    <alias index="20" field="green_type" name=""/>
    <alias index="21" field="interpretation" name=""/>
    <alias index="22" field="in_aoi" name=""/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="provider"/>
    <policy policy="Duplicate" field="dataset"/>
    <policy policy="Duplicate" field="source_url"/>
    <policy policy="Duplicate" field="retrieved_at"/>
    <policy policy="Duplicate" field="release_date"/>
    <policy policy="Duplicate" field="license"/>
    <policy policy="Duplicate" field="crs_original"/>
    <policy policy="Duplicate" field="processing_steps"/>
    <policy policy="Duplicate" field="is_inferred"/>
    <policy policy="Duplicate" field="evidence"/>
    <policy policy="Duplicate" field="confidence"/>
    <policy policy="Duplicate" field="spatial_accuracy_m"/>
    <policy policy="Duplicate" field="canonical_id"/>
    <policy policy="Duplicate" field="osm_type"/>
    <policy policy="Duplicate" field="osm_id"/>
    <policy policy="Duplicate" field="snapshot_date"/>
    <policy policy="Duplicate" field="name"/>
    <policy policy="Duplicate" field="access"/>
    <policy policy="Duplicate" field="tags_json"/>
    <policy policy="Duplicate" field="green_type"/>
    <policy policy="Duplicate" field="interpretation"/>
    <policy policy="Duplicate" field="in_aoi"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="provider"/>
    <policy policy="Duplicate" field="dataset"/>
    <policy policy="Duplicate" field="source_url"/>
    <policy policy="Duplicate" field="retrieved_at"/>
    <policy policy="Duplicate" field="release_date"/>
    <policy policy="Duplicate" field="license"/>
    <policy policy="Duplicate" field="crs_original"/>
    <policy policy="Duplicate" field="processing_steps"/>
    <policy policy="Duplicate" field="is_inferred"/>
    <policy policy="Duplicate" field="evidence"/>
    <policy policy="Duplicate" field="confidence"/>
    <policy policy="Duplicate" field="spatial_accuracy_m"/>
    <policy policy="Duplicate" field="canonical_id"/>
    <policy policy="Duplicate" field="osm_type"/>
    <policy policy="Duplicate" field="osm_id"/>
    <policy policy="Duplicate" field="snapshot_date"/>
    <policy policy="Duplicate" field="name"/>
    <policy policy="Duplicate" field="access"/>
    <policy policy="Duplicate" field="tags_json"/>
    <policy policy="Duplicate" field="green_type"/>
    <policy policy="Duplicate" field="interpretation"/>
    <policy policy="Duplicate" field="in_aoi"/>
  </duplicatePolicies>
  <defaults>
    <default applyOnUpdate="0" field="fid" expression=""/>
    <default applyOnUpdate="0" field="provider" expression=""/>
    <default applyOnUpdate="0" field="dataset" expression=""/>
    <default applyOnUpdate="0" field="source_url" expression=""/>
    <default applyOnUpdate="0" field="retrieved_at" expression=""/>
    <default applyOnUpdate="0" field="release_date" expression=""/>
    <default applyOnUpdate="0" field="license" expression=""/>
    <default applyOnUpdate="0" field="crs_original" expression=""/>
    <default applyOnUpdate="0" field="processing_steps" expression=""/>
    <default applyOnUpdate="0" field="is_inferred" expression=""/>
    <default applyOnUpdate="0" field="evidence" expression=""/>
    <default applyOnUpdate="0" field="confidence" expression=""/>
    <default applyOnUpdate="0" field="spatial_accuracy_m" expression=""/>
    <default applyOnUpdate="0" field="canonical_id" expression=""/>
    <default applyOnUpdate="0" field="osm_type" expression=""/>
    <default applyOnUpdate="0" field="osm_id" expression=""/>
    <default applyOnUpdate="0" field="snapshot_date" expression=""/>
    <default applyOnUpdate="0" field="name" expression=""/>
    <default applyOnUpdate="0" field="access" expression=""/>
    <default applyOnUpdate="0" field="tags_json" expression=""/>
    <default applyOnUpdate="0" field="green_type" expression=""/>
    <default applyOnUpdate="0" field="interpretation" expression=""/>
    <default applyOnUpdate="0" field="in_aoi" expression=""/>
  </defaults>
  <constraints>
    <constraint notnull_strength="1" constraints="3" unique_strength="1" exp_strength="0" field="fid"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="provider"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="dataset"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="source_url"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="retrieved_at"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="release_date"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="license"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="crs_original"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="processing_steps"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="is_inferred"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="evidence"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="confidence"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="spatial_accuracy_m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="canonical_id"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="osm_type"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="osm_id"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="snapshot_date"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="name"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="access"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="tags_json"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="green_type"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="interpretation"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="in_aoi"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="provider"/>
    <constraint exp="" desc="" field="dataset"/>
    <constraint exp="" desc="" field="source_url"/>
    <constraint exp="" desc="" field="retrieved_at"/>
    <constraint exp="" desc="" field="release_date"/>
    <constraint exp="" desc="" field="license"/>
    <constraint exp="" desc="" field="crs_original"/>
    <constraint exp="" desc="" field="processing_steps"/>
    <constraint exp="" desc="" field="is_inferred"/>
    <constraint exp="" desc="" field="evidence"/>
    <constraint exp="" desc="" field="confidence"/>
    <constraint exp="" desc="" field="spatial_accuracy_m"/>
    <constraint exp="" desc="" field="canonical_id"/>
    <constraint exp="" desc="" field="osm_type"/>
    <constraint exp="" desc="" field="osm_id"/>
    <constraint exp="" desc="" field="snapshot_date"/>
    <constraint exp="" desc="" field="name"/>
    <constraint exp="" desc="" field="access"/>
    <constraint exp="" desc="" field="tags_json"/>
    <constraint exp="" desc="" field="green_type"/>
    <constraint exp="" desc="" field="interpretation"/>
    <constraint exp="" desc="" field="in_aoi"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
