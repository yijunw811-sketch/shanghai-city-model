<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" simplifyLocal="1" minScale="100000000" simplifyMaxScale="1" autoRefreshMode="Disabled" autoRefreshTime="0" simplifyDrawingTol="1" labelsEnabled="0" readOnly="0" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" maxScale="0" simplifyAlgorithm="0" symbologyReferenceScale="-1" version="3.40.6-Bratislava">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal enabled="0" durationField="" limitMode="0" mode="0" fixedDuration="0" startField="" startExpression="" durationUnit="min" endField="" accumulate="0" endExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation clamping="Terrain" symbology="Line" showMarkerSymbolInSurfacePlots="0" zscale="1" type="IndividualFeatures" extrusionEnabled="0" zoffset="0" binding="Centroid" extrusion="0" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" type="line" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{530b64f9-b7a6-40af-a5a0-615095c5f993}" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="62,138,134,255,hsv:0.49166666666666664,0.5490196078431373,0.54117647058823526,1" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{7d7e2b9b-ea7a-44d2-bdbb-df02b479a961}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="62,138,134,255,hsv:0.49166666666666664,0.5490196078431373,0.54117647058823526,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="44,99,96,255,hsv:0.49166666666666664,0.5490196078431373,0.38654154268711377,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" type="marker" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{73752cdf-0f6a-4e7a-923f-6dbd48b37832}" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="62,138,134,255,hsv:0.49166666666666664,0.5490196078431373,0.54117647058823526,1" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="44,99,96,255,hsv:0.49166666666666664,0.5490196078431373,0.38654154268711377,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="graduatedSymbol" graduatedMethod="GraduatedColor" forceraster="0" attr="height_m" referencescale="-1" symbollevels="0">
    <ranges>
      <range render="true" upper="12.000000000000000" symbol="0" lower="3.000000000000000" uuid="{b6310a26-8ffa-4a6c-93ff-dbb92aefb76a}" label="3 – 12"/>
      <range render="true" upper="12.000000000000000" symbol="1" lower="12.000000000000000" uuid="{275ed434-1a36-4cd0-b3a6-eebac6584de2}" label="12 – 12"/>
      <range render="true" upper="12.000000000000000" symbol="2" lower="12.000000000000000" uuid="{06900302-7216-45cc-bc24-1f14f0899a4f}" label="12 – 12"/>
      <range render="true" upper="12.000000000000000" symbol="3" lower="12.000000000000000" uuid="{d3fe5369-5869-4e2a-8ca1-634c8a38e814}" label="12 – 12"/>
      <range render="true" upper="108.000000000000000" symbol="4" lower="12.000000000000000" uuid="{f64bcbae-327f-4d9c-8e89-0ea90adcfa31}" label="12 – 108"/>
    </ranges>
    <symbols>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{e5902dd9-ad8a-478f-a3e0-1a0b3c3347fd}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="237,233,215,255,rgb:0.92941176470588238,0.9137254901960784,0.84313725490196079,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{4b91592b-8318-495d-9b77-d4629d7cbf7c}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="216,197,158,255,rgb:0.84705882352941175,0.77254901960784317,0.61960784313725492,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="2" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{780cd965-8072-4134-b64a-0d43d468be75}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="188,155,116,255,rgb:0.73725490196078436,0.60784313725490191,0.45490196078431372,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="3" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{a013c904-98d1-4f81-a37d-ccfc6127f97d}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="155,113,86,255,rgb:0.60784313725490191,0.44313725490196076,0.33725490196078434,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="4" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{beadeeed-5709-40b2-a262-51bc37513f82}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="112,78,66,255,rgb:0.4392156862745098,0.30588235294117649,0.25882352941176473,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <classificationMethod id="Custom">
      <symmetricMode enabled="0" symmetrypoint="0" astride="0"/>
      <labelFormat trimtrailingzeroes="1" format="%1 - %2" labelprecision="4"/>
      <parameters>
        <Option/>
      </parameters>
      <extraInformation/>
    </classificationMethod>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option value="" type="QString"/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source_date">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="license">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_type">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags_json">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="part">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="min_height_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_source">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="confidence">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="overture_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="feature_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="upstream_dataset">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_explanation">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="context_landuse">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="footprint_removed_fraction">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="model_precision_grid_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="provider">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dataset">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source_url">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="retrieved_at">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="release_date">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="crs_original">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="processing_steps">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="is_inferred">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="evidence">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="spatial_accuracy_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="footprint_m2">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_is_measured">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_quality">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_class">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="longitude">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="latitude">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="coordinate_meaning">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="fid" name=""/>
    <alias index="1" field="source" name=""/>
    <alias index="2" field="source_date" name=""/>
    <alias index="3" field="license" name=""/>
    <alias index="4" field="osm_type" name=""/>
    <alias index="5" field="osm_id" name=""/>
    <alias index="6" field="name" name=""/>
    <alias index="7" field="tags_json" name=""/>
    <alias index="8" field="part" name=""/>
    <alias index="9" field="building" name=""/>
    <alias index="10" field="height_m" name=""/>
    <alias index="11" field="min_height_m" name=""/>
    <alias index="12" field="height_source" name=""/>
    <alias index="13" field="confidence" name=""/>
    <alias index="14" field="overture_id" name=""/>
    <alias index="15" field="feature_id" name=""/>
    <alias index="16" field="upstream_dataset" name=""/>
    <alias index="17" field="height_explanation" name=""/>
    <alias index="18" field="context_landuse" name=""/>
    <alias index="19" field="footprint_removed_fraction" name=""/>
    <alias index="20" field="model_precision_grid_m" name=""/>
    <alias index="21" field="provider" name=""/>
    <alias index="22" field="dataset" name=""/>
    <alias index="23" field="source_url" name=""/>
    <alias index="24" field="retrieved_at" name=""/>
    <alias index="25" field="release_date" name=""/>
    <alias index="26" field="crs_original" name=""/>
    <alias index="27" field="processing_steps" name=""/>
    <alias index="28" field="is_inferred" name=""/>
    <alias index="29" field="evidence" name=""/>
    <alias index="30" field="spatial_accuracy_m" name=""/>
    <alias index="31" field="footprint_m2" name=""/>
    <alias index="32" field="height_is_measured" name=""/>
    <alias index="33" field="height_quality" name=""/>
    <alias index="34" field="height_class" name=""/>
    <alias index="35" field="longitude" name=""/>
    <alias index="36" field="latitude" name=""/>
    <alias index="37" field="coordinate_meaning" name=""/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="source"/>
    <policy policy="Duplicate" field="source_date"/>
    <policy policy="Duplicate" field="license"/>
    <policy policy="Duplicate" field="osm_type"/>
    <policy policy="Duplicate" field="osm_id"/>
    <policy policy="Duplicate" field="name"/>
    <policy policy="Duplicate" field="tags_json"/>
    <policy policy="Duplicate" field="part"/>
    <policy policy="Duplicate" field="building"/>
    <policy policy="Duplicate" field="height_m"/>
    <policy policy="Duplicate" field="min_height_m"/>
    <policy policy="Duplicate" field="height_source"/>
    <policy policy="Duplicate" field="confidence"/>
    <policy policy="Duplicate" field="overture_id"/>
    <policy policy="Duplicate" field="feature_id"/>
    <policy policy="Duplicate" field="upstream_dataset"/>
    <policy policy="Duplicate" field="height_explanation"/>
    <policy policy="Duplicate" field="context_landuse"/>
    <policy policy="Duplicate" field="footprint_removed_fraction"/>
    <policy policy="Duplicate" field="model_precision_grid_m"/>
    <policy policy="Duplicate" field="provider"/>
    <policy policy="Duplicate" field="dataset"/>
    <policy policy="Duplicate" field="source_url"/>
    <policy policy="Duplicate" field="retrieved_at"/>
    <policy policy="Duplicate" field="release_date"/>
    <policy policy="Duplicate" field="crs_original"/>
    <policy policy="Duplicate" field="processing_steps"/>
    <policy policy="Duplicate" field="is_inferred"/>
    <policy policy="Duplicate" field="evidence"/>
    <policy policy="Duplicate" field="spatial_accuracy_m"/>
    <policy policy="Duplicate" field="footprint_m2"/>
    <policy policy="Duplicate" field="height_is_measured"/>
    <policy policy="Duplicate" field="height_quality"/>
    <policy policy="Duplicate" field="height_class"/>
    <policy policy="Duplicate" field="longitude"/>
    <policy policy="Duplicate" field="latitude"/>
    <policy policy="Duplicate" field="coordinate_meaning"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="source"/>
    <policy policy="Duplicate" field="source_date"/>
    <policy policy="Duplicate" field="license"/>
    <policy policy="Duplicate" field="osm_type"/>
    <policy policy="Duplicate" field="osm_id"/>
    <policy policy="Duplicate" field="name"/>
    <policy policy="Duplicate" field="tags_json"/>
    <policy policy="Duplicate" field="part"/>
    <policy policy="Duplicate" field="building"/>
    <policy policy="Duplicate" field="height_m"/>
    <policy policy="Duplicate" field="min_height_m"/>
    <policy policy="Duplicate" field="height_source"/>
    <policy policy="Duplicate" field="confidence"/>
    <policy policy="Duplicate" field="overture_id"/>
    <policy policy="Duplicate" field="feature_id"/>
    <policy policy="Duplicate" field="upstream_dataset"/>
    <policy policy="Duplicate" field="height_explanation"/>
    <policy policy="Duplicate" field="context_landuse"/>
    <policy policy="Duplicate" field="footprint_removed_fraction"/>
    <policy policy="Duplicate" field="model_precision_grid_m"/>
    <policy policy="Duplicate" field="provider"/>
    <policy policy="Duplicate" field="dataset"/>
    <policy policy="Duplicate" field="source_url"/>
    <policy policy="Duplicate" field="retrieved_at"/>
    <policy policy="Duplicate" field="release_date"/>
    <policy policy="Duplicate" field="crs_original"/>
    <policy policy="Duplicate" field="processing_steps"/>
    <policy policy="Duplicate" field="is_inferred"/>
    <policy policy="Duplicate" field="evidence"/>
    <policy policy="Duplicate" field="spatial_accuracy_m"/>
    <policy policy="Duplicate" field="footprint_m2"/>
    <policy policy="Duplicate" field="height_is_measured"/>
    <policy policy="Duplicate" field="height_quality"/>
    <policy policy="Duplicate" field="height_class"/>
    <policy policy="Duplicate" field="longitude"/>
    <policy policy="Duplicate" field="latitude"/>
    <policy policy="Duplicate" field="coordinate_meaning"/>
  </duplicatePolicies>
  <defaults>
    <default applyOnUpdate="0" field="fid" expression=""/>
    <default applyOnUpdate="0" field="source" expression=""/>
    <default applyOnUpdate="0" field="source_date" expression=""/>
    <default applyOnUpdate="0" field="license" expression=""/>
    <default applyOnUpdate="0" field="osm_type" expression=""/>
    <default applyOnUpdate="0" field="osm_id" expression=""/>
    <default applyOnUpdate="0" field="name" expression=""/>
    <default applyOnUpdate="0" field="tags_json" expression=""/>
    <default applyOnUpdate="0" field="part" expression=""/>
    <default applyOnUpdate="0" field="building" expression=""/>
    <default applyOnUpdate="0" field="height_m" expression=""/>
    <default applyOnUpdate="0" field="min_height_m" expression=""/>
    <default applyOnUpdate="0" field="height_source" expression=""/>
    <default applyOnUpdate="0" field="confidence" expression=""/>
    <default applyOnUpdate="0" field="overture_id" expression=""/>
    <default applyOnUpdate="0" field="feature_id" expression=""/>
    <default applyOnUpdate="0" field="upstream_dataset" expression=""/>
    <default applyOnUpdate="0" field="height_explanation" expression=""/>
    <default applyOnUpdate="0" field="context_landuse" expression=""/>
    <default applyOnUpdate="0" field="footprint_removed_fraction" expression=""/>
    <default applyOnUpdate="0" field="model_precision_grid_m" expression=""/>
    <default applyOnUpdate="0" field="provider" expression=""/>
    <default applyOnUpdate="0" field="dataset" expression=""/>
    <default applyOnUpdate="0" field="source_url" expression=""/>
    <default applyOnUpdate="0" field="retrieved_at" expression=""/>
    <default applyOnUpdate="0" field="release_date" expression=""/>
    <default applyOnUpdate="0" field="crs_original" expression=""/>
    <default applyOnUpdate="0" field="processing_steps" expression=""/>
    <default applyOnUpdate="0" field="is_inferred" expression=""/>
    <default applyOnUpdate="0" field="evidence" expression=""/>
    <default applyOnUpdate="0" field="spatial_accuracy_m" expression=""/>
    <default applyOnUpdate="0" field="footprint_m2" expression=""/>
    <default applyOnUpdate="0" field="height_is_measured" expression=""/>
    <default applyOnUpdate="0" field="height_quality" expression=""/>
    <default applyOnUpdate="0" field="height_class" expression=""/>
    <default applyOnUpdate="0" field="longitude" expression=""/>
    <default applyOnUpdate="0" field="latitude" expression=""/>
    <default applyOnUpdate="0" field="coordinate_meaning" expression=""/>
  </defaults>
  <constraints>
    <constraint notnull_strength="1" constraints="3" unique_strength="1" exp_strength="0" field="fid"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="source"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="source_date"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="license"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="osm_type"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="osm_id"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="name"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="tags_json"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="part"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="building"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="height_m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="min_height_m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="height_source"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="confidence"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="overture_id"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="feature_id"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="upstream_dataset"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="height_explanation"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="context_landuse"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="footprint_removed_fraction"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="model_precision_grid_m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="provider"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="dataset"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="source_url"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="retrieved_at"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="release_date"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="crs_original"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="processing_steps"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="is_inferred"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="evidence"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="spatial_accuracy_m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="footprint_m2"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="height_is_measured"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="height_quality"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="height_class"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="longitude"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="latitude"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="coordinate_meaning"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="source"/>
    <constraint exp="" desc="" field="source_date"/>
    <constraint exp="" desc="" field="license"/>
    <constraint exp="" desc="" field="osm_type"/>
    <constraint exp="" desc="" field="osm_id"/>
    <constraint exp="" desc="" field="name"/>
    <constraint exp="" desc="" field="tags_json"/>
    <constraint exp="" desc="" field="part"/>
    <constraint exp="" desc="" field="building"/>
    <constraint exp="" desc="" field="height_m"/>
    <constraint exp="" desc="" field="min_height_m"/>
    <constraint exp="" desc="" field="height_source"/>
    <constraint exp="" desc="" field="confidence"/>
    <constraint exp="" desc="" field="overture_id"/>
    <constraint exp="" desc="" field="feature_id"/>
    <constraint exp="" desc="" field="upstream_dataset"/>
    <constraint exp="" desc="" field="height_explanation"/>
    <constraint exp="" desc="" field="context_landuse"/>
    <constraint exp="" desc="" field="footprint_removed_fraction"/>
    <constraint exp="" desc="" field="model_precision_grid_m"/>
    <constraint exp="" desc="" field="provider"/>
    <constraint exp="" desc="" field="dataset"/>
    <constraint exp="" desc="" field="source_url"/>
    <constraint exp="" desc="" field="retrieved_at"/>
    <constraint exp="" desc="" field="release_date"/>
    <constraint exp="" desc="" field="crs_original"/>
    <constraint exp="" desc="" field="processing_steps"/>
    <constraint exp="" desc="" field="is_inferred"/>
    <constraint exp="" desc="" field="evidence"/>
    <constraint exp="" desc="" field="spatial_accuracy_m"/>
    <constraint exp="" desc="" field="footprint_m2"/>
    <constraint exp="" desc="" field="height_is_measured"/>
    <constraint exp="" desc="" field="height_quality"/>
    <constraint exp="" desc="" field="height_class"/>
    <constraint exp="" desc="" field="longitude"/>
    <constraint exp="" desc="" field="latitude"/>
    <constraint exp="" desc="" field="coordinate_meaning"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
