<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" simplifyLocal="1" minScale="100000000" simplifyMaxScale="1" autoRefreshMode="Disabled" autoRefreshTime="0" simplifyDrawingTol="1" labelsEnabled="0" readOnly="0" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" maxScale="0" simplifyAlgorithm="0" symbologyReferenceScale="-1" version="3.40.6-Bratislava">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal enabled="0" durationField="" limitMode="0" mode="0" fixedDuration="0" startField="" startExpression="" durationUnit="min" endField="" accumulate="0" endExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation clamping="Terrain" symbology="Line" showMarkerSymbolInSurfacePlots="0" zscale="1" type="IndividualFeatures" extrusionEnabled="0" zoffset="0" binding="Centroid" extrusion="0" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" type="line" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{a1364dbc-ce5c-4106-80c6-f3632f6205a5}" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="240,164,221,255,hsv:0.875,0.31764705882352939,0.94117647058823528,1" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{a735bced-af30-44fd-a3eb-ab818aa63c11}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="240,164,221,255,hsv:0.875,0.31764705882352939,0.94117647058823528,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="171,117,158,255,hsv:0.875,0.31764705882352939,0.67226672770275431,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" type="marker" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{da86d4ee-bb8e-4a62-b1e2-d69c2f01b9e0}" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="240,164,221,255,hsv:0.875,0.31764705882352939,0.94117647058823528,1" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="171,117,158,255,hsv:0.875,0.31764705882352939,0.67226672770275431,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="singleSymbol" forceraster="0" referencescale="-1" symbollevels="0">
    <symbols>
      <symbol alpha="1" type="line" force_rhr="0" clip_to_extent="1" is_animated="0" name="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{bd3ce2db-e58f-4916-9d47-f86a163a75a5}" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="158,119,96,255,rgb:0.61960784313725492,0.46666666666666667,0.37647058823529411,1" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.26" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option value="" type="QString"/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="way_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="u">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="v">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="segment_index">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="highway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="length_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="walk">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cycle">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="vehicle">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="layer">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="bridge">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tunnel">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="oneway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="width">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="lanes">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="sidewalk">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cycleway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="foot">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="bicycle">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="access">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="wheelchair">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="surface">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source_url">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="license">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="access_method">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="in_aoi">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="fid" name=""/>
    <alias index="1" field="way_id" name=""/>
    <alias index="2" field="u" name=""/>
    <alias index="3" field="v" name=""/>
    <alias index="4" field="segment_index" name=""/>
    <alias index="5" field="highway" name=""/>
    <alias index="6" field="name" name=""/>
    <alias index="7" field="length_m" name=""/>
    <alias index="8" field="walk" name=""/>
    <alias index="9" field="cycle" name=""/>
    <alias index="10" field="vehicle" name=""/>
    <alias index="11" field="layer" name=""/>
    <alias index="12" field="bridge" name=""/>
    <alias index="13" field="tunnel" name=""/>
    <alias index="14" field="oneway" name=""/>
    <alias index="15" field="width" name=""/>
    <alias index="16" field="lanes" name=""/>
    <alias index="17" field="sidewalk" name=""/>
    <alias index="18" field="cycleway" name=""/>
    <alias index="19" field="foot" name=""/>
    <alias index="20" field="bicycle" name=""/>
    <alias index="21" field="access" name=""/>
    <alias index="22" field="wheelchair" name=""/>
    <alias index="23" field="surface" name=""/>
    <alias index="24" field="source_url" name=""/>
    <alias index="25" field="license" name=""/>
    <alias index="26" field="access_method" name=""/>
    <alias index="27" field="in_aoi" name=""/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="way_id"/>
    <policy policy="Duplicate" field="u"/>
    <policy policy="Duplicate" field="v"/>
    <policy policy="Duplicate" field="segment_index"/>
    <policy policy="Duplicate" field="highway"/>
    <policy policy="Duplicate" field="name"/>
    <policy policy="Duplicate" field="length_m"/>
    <policy policy="Duplicate" field="walk"/>
    <policy policy="Duplicate" field="cycle"/>
    <policy policy="Duplicate" field="vehicle"/>
    <policy policy="Duplicate" field="layer"/>
    <policy policy="Duplicate" field="bridge"/>
    <policy policy="Duplicate" field="tunnel"/>
    <policy policy="Duplicate" field="oneway"/>
    <policy policy="Duplicate" field="width"/>
    <policy policy="Duplicate" field="lanes"/>
    <policy policy="Duplicate" field="sidewalk"/>
    <policy policy="Duplicate" field="cycleway"/>
    <policy policy="Duplicate" field="foot"/>
    <policy policy="Duplicate" field="bicycle"/>
    <policy policy="Duplicate" field="access"/>
    <policy policy="Duplicate" field="wheelchair"/>
    <policy policy="Duplicate" field="surface"/>
    <policy policy="Duplicate" field="source_url"/>
    <policy policy="Duplicate" field="license"/>
    <policy policy="Duplicate" field="access_method"/>
    <policy policy="Duplicate" field="in_aoi"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="way_id"/>
    <policy policy="Duplicate" field="u"/>
    <policy policy="Duplicate" field="v"/>
    <policy policy="Duplicate" field="segment_index"/>
    <policy policy="Duplicate" field="highway"/>
    <policy policy="Duplicate" field="name"/>
    <policy policy="Duplicate" field="length_m"/>
    <policy policy="Duplicate" field="walk"/>
    <policy policy="Duplicate" field="cycle"/>
    <policy policy="Duplicate" field="vehicle"/>
    <policy policy="Duplicate" field="layer"/>
    <policy policy="Duplicate" field="bridge"/>
    <policy policy="Duplicate" field="tunnel"/>
    <policy policy="Duplicate" field="oneway"/>
    <policy policy="Duplicate" field="width"/>
    <policy policy="Duplicate" field="lanes"/>
    <policy policy="Duplicate" field="sidewalk"/>
    <policy policy="Duplicate" field="cycleway"/>
    <policy policy="Duplicate" field="foot"/>
    <policy policy="Duplicate" field="bicycle"/>
    <policy policy="Duplicate" field="access"/>
    <policy policy="Duplicate" field="wheelchair"/>
    <policy policy="Duplicate" field="surface"/>
    <policy policy="Duplicate" field="source_url"/>
    <policy policy="Duplicate" field="license"/>
    <policy policy="Duplicate" field="access_method"/>
    <policy policy="Duplicate" field="in_aoi"/>
  </duplicatePolicies>
  <defaults>
    <default applyOnUpdate="0" field="fid" expression=""/>
    <default applyOnUpdate="0" field="way_id" expression=""/>
    <default applyOnUpdate="0" field="u" expression=""/>
    <default applyOnUpdate="0" field="v" expression=""/>
    <default applyOnUpdate="0" field="segment_index" expression=""/>
    <default applyOnUpdate="0" field="highway" expression=""/>
    <default applyOnUpdate="0" field="name" expression=""/>
    <default applyOnUpdate="0" field="length_m" expression=""/>
    <default applyOnUpdate="0" field="walk" expression=""/>
    <default applyOnUpdate="0" field="cycle" expression=""/>
    <default applyOnUpdate="0" field="vehicle" expression=""/>
    <default applyOnUpdate="0" field="layer" expression=""/>
    <default applyOnUpdate="0" field="bridge" expression=""/>
    <default applyOnUpdate="0" field="tunnel" expression=""/>
    <default applyOnUpdate="0" field="oneway" expression=""/>
    <default applyOnUpdate="0" field="width" expression=""/>
    <default applyOnUpdate="0" field="lanes" expression=""/>
    <default applyOnUpdate="0" field="sidewalk" expression=""/>
    <default applyOnUpdate="0" field="cycleway" expression=""/>
    <default applyOnUpdate="0" field="foot" expression=""/>
    <default applyOnUpdate="0" field="bicycle" expression=""/>
    <default applyOnUpdate="0" field="access" expression=""/>
    <default applyOnUpdate="0" field="wheelchair" expression=""/>
    <default applyOnUpdate="0" field="surface" expression=""/>
    <default applyOnUpdate="0" field="source_url" expression=""/>
    <default applyOnUpdate="0" field="license" expression=""/>
    <default applyOnUpdate="0" field="access_method" expression=""/>
    <default applyOnUpdate="0" field="in_aoi" expression=""/>
  </defaults>
  <constraints>
    <constraint notnull_strength="1" constraints="3" unique_strength="1" exp_strength="0" field="fid"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="way_id"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="u"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="v"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="segment_index"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="highway"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="name"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="length_m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="walk"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="cycle"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="vehicle"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="layer"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="bridge"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="tunnel"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="oneway"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="width"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="lanes"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="sidewalk"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="cycleway"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="foot"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="bicycle"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="access"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="wheelchair"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="surface"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="source_url"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="license"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="access_method"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="in_aoi"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="way_id"/>
    <constraint exp="" desc="" field="u"/>
    <constraint exp="" desc="" field="v"/>
    <constraint exp="" desc="" field="segment_index"/>
    <constraint exp="" desc="" field="highway"/>
    <constraint exp="" desc="" field="name"/>
    <constraint exp="" desc="" field="length_m"/>
    <constraint exp="" desc="" field="walk"/>
    <constraint exp="" desc="" field="cycle"/>
    <constraint exp="" desc="" field="vehicle"/>
    <constraint exp="" desc="" field="layer"/>
    <constraint exp="" desc="" field="bridge"/>
    <constraint exp="" desc="" field="tunnel"/>
    <constraint exp="" desc="" field="oneway"/>
    <constraint exp="" desc="" field="width"/>
    <constraint exp="" desc="" field="lanes"/>
    <constraint exp="" desc="" field="sidewalk"/>
    <constraint exp="" desc="" field="cycleway"/>
    <constraint exp="" desc="" field="foot"/>
    <constraint exp="" desc="" field="bicycle"/>
    <constraint exp="" desc="" field="access"/>
    <constraint exp="" desc="" field="wheelchair"/>
    <constraint exp="" desc="" field="surface"/>
    <constraint exp="" desc="" field="source_url"/>
    <constraint exp="" desc="" field="license"/>
    <constraint exp="" desc="" field="access_method"/>
    <constraint exp="" desc="" field="in_aoi"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
