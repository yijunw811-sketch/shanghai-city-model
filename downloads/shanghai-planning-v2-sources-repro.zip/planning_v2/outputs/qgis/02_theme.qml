<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyDrawingHints="1" simplifyLocal="1" minScale="100000000" simplifyMaxScale="1" autoRefreshMode="Disabled" autoRefreshTime="0" simplifyDrawingTol="1" labelsEnabled="0" readOnly="0" styleCategories="AllStyleCategories" hasScaleBasedVisibilityFlag="0" maxScale="0" simplifyAlgorithm="0" symbologyReferenceScale="-1" version="3.40.6-Bratislava">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal enabled="0" durationField="" limitMode="0" mode="0" fixedDuration="0" startField="" startExpression="" durationUnit="min" endField="" accumulate="0" endExpression="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation clamping="Terrain" symbology="Line" showMarkerSymbolInSurfacePlots="0" zscale="1" type="IndividualFeatures" extrusionEnabled="0" zoffset="0" binding="Centroid" extrusion="0" respectLayerSymbol="1">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol alpha="1" type="line" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{ff8ba7b3-e694-496b-8643-706618acd210}" locked="0" class="SimpleLine">
          <Option type="Map">
            <Option value="0" type="QString" name="align_dash_pattern"/>
            <Option value="square" type="QString" name="capstyle"/>
            <Option value="5;2" type="QString" name="customdash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="customdash_map_unit_scale"/>
            <Option value="MM" type="QString" name="customdash_unit"/>
            <Option value="0" type="QString" name="dash_pattern_offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="dash_pattern_offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="dash_pattern_offset_unit"/>
            <Option value="0" type="QString" name="draw_inside_polygon"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="238,122,102,255,hsv:0.025,0.5725490196078431,0.93333333333333335,1" type="QString" name="line_color"/>
            <Option value="solid" type="QString" name="line_style"/>
            <Option value="0.6" type="QString" name="line_width"/>
            <Option value="MM" type="QString" name="line_width_unit"/>
            <Option value="0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="0" type="QString" name="ring_filter"/>
            <Option value="0" type="QString" name="trim_distance_end"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_end_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_end_unit"/>
            <Option value="0" type="QString" name="trim_distance_start"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="trim_distance_start_map_unit_scale"/>
            <Option value="MM" type="QString" name="trim_distance_start_unit"/>
            <Option value="0" type="QString" name="tweak_dash_pattern_on_corners"/>
            <Option value="0" type="QString" name="use_custom_dash"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{ead5d34b-b55b-4696-9fbc-7cad48a8c1a2}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="238,122,102,255,hsv:0.025,0.5725490196078431,0.93333333333333335,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="170,87,73,255,hsv:0.025,0.5725490196078431,0.66666666666666663,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol alpha="1" type="marker" force_rhr="0" clip_to_extent="1" is_animated="0" name="" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{2c49fac1-0180-43f1-9e19-27e3ba3f73a8}" locked="0" class="SimpleMarker">
          <Option type="Map">
            <Option value="0" type="QString" name="angle"/>
            <Option value="square" type="QString" name="cap_style"/>
            <Option value="238,122,102,255,hsv:0.025,0.5725490196078431,0.93333333333333335,1" type="QString" name="color"/>
            <Option value="1" type="QString" name="horizontal_anchor_point"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="diamond" type="QString" name="name"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="170,87,73,255,hsv:0.025,0.5725490196078431,0.66666666666666663,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.2" type="QString" name="outline_width"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="outline_width_map_unit_scale"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="diameter" type="QString" name="scale_method"/>
            <Option value="3" type="QString" name="size"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="size_map_unit_scale"/>
            <Option value="MM" type="QString" name="size_unit"/>
            <Option value="1" type="QString" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="graduatedSymbol" graduatedMethod="GraduatedColor" forceraster="0" attr="building_density" referencescale="-1" symbollevels="0">
    <ranges>
      <range render="true" upper="0.177883493920475" symbol="0" lower="0.023776015069848" uuid="{f6243d83-93f5-4048-acae-28a034f31a93}" label="0.0238 – 0.178"/>
      <range render="true" upper="0.202851610252892" symbol="1" lower="0.177883493920475" uuid="{381fb663-098a-42ee-9907-946744e12240}" label="0.178 – 0.203"/>
      <range render="true" upper="0.234705074207330" symbol="2" lower="0.202851610252892" uuid="{237da864-e6f7-4330-9e22-b41d7947d5c8}" label="0.203 – 0.235"/>
      <range render="true" upper="0.274235423047841" symbol="3" lower="0.234705074207330" uuid="{7d129be1-ea68-4a8a-9a42-3b19422401d6}" label="0.235 – 0.274"/>
      <range render="true" upper="0.448716042227728" symbol="4" lower="0.274235423047841" uuid="{20049a5d-491c-4991-a596-6b4c3a699db4}" label="0.274 – 0.449"/>
    </ranges>
    <symbols>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{34c4bc8b-5d37-45ec-a2b1-03bcab9eb2b4}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="237,233,215,255,rgb:0.92941176470588238,0.9137254901960784,0.84313725490196079,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="1" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{536b48a8-739c-497f-8d4c-4bc336342893}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="216,197,158,255,rgb:0.84705882352941175,0.77254901960784317,0.61960784313725492,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="2" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{23a0cef7-2d24-4f13-b7f1-68b5d3ad06e1}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="188,155,116,255,rgb:0.73725490196078436,0.60784313725490191,0.45490196078431372,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="3" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{0c5b6764-aa3f-4d2b-89aa-d81a0b1a8d62}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="155,113,86,255,rgb:0.60784313725490191,0.44313725490196076,0.33725490196078434,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="fill" force_rhr="0" clip_to_extent="1" is_animated="0" name="4" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" type="QString" name="name"/>
            <Option name="properties"/>
            <Option value="collection" type="QString" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" pass="0" id="{101ad3d0-6404-41a2-93bf-862788dabedb}" locked="0" class="SimpleFill">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" type="QString" name="border_width_map_unit_scale"/>
            <Option value="112,78,66,255,rgb:0.4392156862745098,0.30588235294117649,0.25882352941176473,1" type="QString" name="color"/>
            <Option value="bevel" type="QString" name="joinstyle"/>
            <Option value="0,0" type="QString" name="offset"/>
            <Option value="3x:0,0,0,0,0,0" type="QString" name="offset_map_unit_scale"/>
            <Option value="MM" type="QString" name="offset_unit"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" type="QString" name="outline_color"/>
            <Option value="solid" type="QString" name="outline_style"/>
            <Option value="0.26" type="QString" name="outline_width"/>
            <Option value="MM" type="QString" name="outline_width_unit"/>
            <Option value="solid" type="QString" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" type="QString" name="name"/>
              <Option name="properties"/>
              <Option value="collection" type="QString" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <classificationMethod id="Custom">
      <symmetricMode enabled="0" symmetrypoint="0" astride="0"/>
      <labelFormat trimtrailingzeroes="1" format="%1 - %2" labelprecision="4"/>
      <parameters>
        <Option/>
      </parameters>
      <extraInformation/>
    </classificationMethod>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" type="QString" name="name"/>
        <Option name="properties"/>
        <Option value="collection" type="QString" name="type"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks type="StringList">
      <Option value="" type="QString"/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="grid_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="area_m2">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="edge_fraction">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building_density">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="volume_proxy_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="vehicle_density_km_km2">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="walk_density_km_km2">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cycle_density_km_km2">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="poi_count">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="commercial_poi">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="poi_entropy">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="mix_reliability">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="green_fraction">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="mapped_green_fraction">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="mapped_water_fraction">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="worldcover2021_10m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ndbi_summer2026_20m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ndvi_summer2026_10m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ndvi_winter2026_10m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ndwi_winter2026_10m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dsm_slope2021_30m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ndbi_winter2026_20m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dsm_copernicus2021_30m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="lst_summer2026_effective100m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ndwi_summer2026_10m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="daily_service_reachable_walk_fraction">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="research_amenity_priority">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="fid" name=""/>
    <alias index="1" field="grid_id" name=""/>
    <alias index="2" field="area_m2" name=""/>
    <alias index="3" field="edge_fraction" name=""/>
    <alias index="4" field="building_density" name=""/>
    <alias index="5" field="volume_proxy_m" name=""/>
    <alias index="6" field="vehicle_density_km_km2" name=""/>
    <alias index="7" field="walk_density_km_km2" name=""/>
    <alias index="8" field="cycle_density_km_km2" name=""/>
    <alias index="9" field="poi_count" name=""/>
    <alias index="10" field="commercial_poi" name=""/>
    <alias index="11" field="poi_entropy" name=""/>
    <alias index="12" field="mix_reliability" name=""/>
    <alias index="13" field="green_fraction" name=""/>
    <alias index="14" field="mapped_green_fraction" name=""/>
    <alias index="15" field="mapped_water_fraction" name=""/>
    <alias index="16" field="worldcover2021_10m" name=""/>
    <alias index="17" field="ndbi_summer2026_20m" name=""/>
    <alias index="18" field="ndvi_summer2026_10m" name=""/>
    <alias index="19" field="ndvi_winter2026_10m" name=""/>
    <alias index="20" field="ndwi_winter2026_10m" name=""/>
    <alias index="21" field="dsm_slope2021_30m" name=""/>
    <alias index="22" field="ndbi_winter2026_20m" name=""/>
    <alias index="23" field="dsm_copernicus2021_30m" name=""/>
    <alias index="24" field="lst_summer2026_effective100m" name=""/>
    <alias index="25" field="ndwi_summer2026_10m" name=""/>
    <alias index="26" field="daily_service_reachable_walk_fraction" name=""/>
    <alias index="27" field="research_amenity_priority" name=""/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="grid_id"/>
    <policy policy="Duplicate" field="area_m2"/>
    <policy policy="Duplicate" field="edge_fraction"/>
    <policy policy="Duplicate" field="building_density"/>
    <policy policy="Duplicate" field="volume_proxy_m"/>
    <policy policy="Duplicate" field="vehicle_density_km_km2"/>
    <policy policy="Duplicate" field="walk_density_km_km2"/>
    <policy policy="Duplicate" field="cycle_density_km_km2"/>
    <policy policy="Duplicate" field="poi_count"/>
    <policy policy="Duplicate" field="commercial_poi"/>
    <policy policy="Duplicate" field="poi_entropy"/>
    <policy policy="Duplicate" field="mix_reliability"/>
    <policy policy="Duplicate" field="green_fraction"/>
    <policy policy="Duplicate" field="mapped_green_fraction"/>
    <policy policy="Duplicate" field="mapped_water_fraction"/>
    <policy policy="Duplicate" field="worldcover2021_10m"/>
    <policy policy="Duplicate" field="ndbi_summer2026_20m"/>
    <policy policy="Duplicate" field="ndvi_summer2026_10m"/>
    <policy policy="Duplicate" field="ndvi_winter2026_10m"/>
    <policy policy="Duplicate" field="ndwi_winter2026_10m"/>
    <policy policy="Duplicate" field="dsm_slope2021_30m"/>
    <policy policy="Duplicate" field="ndbi_winter2026_20m"/>
    <policy policy="Duplicate" field="dsm_copernicus2021_30m"/>
    <policy policy="Duplicate" field="lst_summer2026_effective100m"/>
    <policy policy="Duplicate" field="ndwi_summer2026_10m"/>
    <policy policy="Duplicate" field="daily_service_reachable_walk_fraction"/>
    <policy policy="Duplicate" field="research_amenity_priority"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="grid_id"/>
    <policy policy="Duplicate" field="area_m2"/>
    <policy policy="Duplicate" field="edge_fraction"/>
    <policy policy="Duplicate" field="building_density"/>
    <policy policy="Duplicate" field="volume_proxy_m"/>
    <policy policy="Duplicate" field="vehicle_density_km_km2"/>
    <policy policy="Duplicate" field="walk_density_km_km2"/>
    <policy policy="Duplicate" field="cycle_density_km_km2"/>
    <policy policy="Duplicate" field="poi_count"/>
    <policy policy="Duplicate" field="commercial_poi"/>
    <policy policy="Duplicate" field="poi_entropy"/>
    <policy policy="Duplicate" field="mix_reliability"/>
    <policy policy="Duplicate" field="green_fraction"/>
    <policy policy="Duplicate" field="mapped_green_fraction"/>
    <policy policy="Duplicate" field="mapped_water_fraction"/>
    <policy policy="Duplicate" field="worldcover2021_10m"/>
    <policy policy="Duplicate" field="ndbi_summer2026_20m"/>
    <policy policy="Duplicate" field="ndvi_summer2026_10m"/>
    <policy policy="Duplicate" field="ndvi_winter2026_10m"/>
    <policy policy="Duplicate" field="ndwi_winter2026_10m"/>
    <policy policy="Duplicate" field="dsm_slope2021_30m"/>
    <policy policy="Duplicate" field="ndbi_winter2026_20m"/>
    <policy policy="Duplicate" field="dsm_copernicus2021_30m"/>
    <policy policy="Duplicate" field="lst_summer2026_effective100m"/>
    <policy policy="Duplicate" field="ndwi_summer2026_10m"/>
    <policy policy="Duplicate" field="daily_service_reachable_walk_fraction"/>
    <policy policy="Duplicate" field="research_amenity_priority"/>
  </duplicatePolicies>
  <defaults>
    <default applyOnUpdate="0" field="fid" expression=""/>
    <default applyOnUpdate="0" field="grid_id" expression=""/>
    <default applyOnUpdate="0" field="area_m2" expression=""/>
    <default applyOnUpdate="0" field="edge_fraction" expression=""/>
    <default applyOnUpdate="0" field="building_density" expression=""/>
    <default applyOnUpdate="0" field="volume_proxy_m" expression=""/>
    <default applyOnUpdate="0" field="vehicle_density_km_km2" expression=""/>
    <default applyOnUpdate="0" field="walk_density_km_km2" expression=""/>
    <default applyOnUpdate="0" field="cycle_density_km_km2" expression=""/>
    <default applyOnUpdate="0" field="poi_count" expression=""/>
    <default applyOnUpdate="0" field="commercial_poi" expression=""/>
    <default applyOnUpdate="0" field="poi_entropy" expression=""/>
    <default applyOnUpdate="0" field="mix_reliability" expression=""/>
    <default applyOnUpdate="0" field="green_fraction" expression=""/>
    <default applyOnUpdate="0" field="mapped_green_fraction" expression=""/>
    <default applyOnUpdate="0" field="mapped_water_fraction" expression=""/>
    <default applyOnUpdate="0" field="worldcover2021_10m" expression=""/>
    <default applyOnUpdate="0" field="ndbi_summer2026_20m" expression=""/>
    <default applyOnUpdate="0" field="ndvi_summer2026_10m" expression=""/>
    <default applyOnUpdate="0" field="ndvi_winter2026_10m" expression=""/>
    <default applyOnUpdate="0" field="ndwi_winter2026_10m" expression=""/>
    <default applyOnUpdate="0" field="dsm_slope2021_30m" expression=""/>
    <default applyOnUpdate="0" field="ndbi_winter2026_20m" expression=""/>
    <default applyOnUpdate="0" field="dsm_copernicus2021_30m" expression=""/>
    <default applyOnUpdate="0" field="lst_summer2026_effective100m" expression=""/>
    <default applyOnUpdate="0" field="ndwi_summer2026_10m" expression=""/>
    <default applyOnUpdate="0" field="daily_service_reachable_walk_fraction" expression=""/>
    <default applyOnUpdate="0" field="research_amenity_priority" expression=""/>
  </defaults>
  <constraints>
    <constraint notnull_strength="1" constraints="3" unique_strength="1" exp_strength="0" field="fid"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="grid_id"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="area_m2"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="edge_fraction"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="building_density"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="volume_proxy_m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="vehicle_density_km_km2"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="walk_density_km_km2"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="cycle_density_km_km2"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="poi_count"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="commercial_poi"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="poi_entropy"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="mix_reliability"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="green_fraction"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="mapped_green_fraction"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="mapped_water_fraction"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="worldcover2021_10m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="ndbi_summer2026_20m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="ndvi_summer2026_10m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="ndvi_winter2026_10m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="ndwi_winter2026_10m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="dsm_slope2021_30m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="ndbi_winter2026_20m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="dsm_copernicus2021_30m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="lst_summer2026_effective100m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="ndwi_summer2026_10m"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="daily_service_reachable_walk_fraction"/>
    <constraint notnull_strength="0" constraints="0" unique_strength="0" exp_strength="0" field="research_amenity_priority"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="grid_id"/>
    <constraint exp="" desc="" field="area_m2"/>
    <constraint exp="" desc="" field="edge_fraction"/>
    <constraint exp="" desc="" field="building_density"/>
    <constraint exp="" desc="" field="volume_proxy_m"/>
    <constraint exp="" desc="" field="vehicle_density_km_km2"/>
    <constraint exp="" desc="" field="walk_density_km_km2"/>
    <constraint exp="" desc="" field="cycle_density_km_km2"/>
    <constraint exp="" desc="" field="poi_count"/>
    <constraint exp="" desc="" field="commercial_poi"/>
    <constraint exp="" desc="" field="poi_entropy"/>
    <constraint exp="" desc="" field="mix_reliability"/>
    <constraint exp="" desc="" field="green_fraction"/>
    <constraint exp="" desc="" field="mapped_green_fraction"/>
    <constraint exp="" desc="" field="mapped_water_fraction"/>
    <constraint exp="" desc="" field="worldcover2021_10m"/>
    <constraint exp="" desc="" field="ndbi_summer2026_20m"/>
    <constraint exp="" desc="" field="ndvi_summer2026_10m"/>
    <constraint exp="" desc="" field="ndvi_winter2026_10m"/>
    <constraint exp="" desc="" field="ndwi_winter2026_10m"/>
    <constraint exp="" desc="" field="dsm_slope2021_30m"/>
    <constraint exp="" desc="" field="ndbi_winter2026_20m"/>
    <constraint exp="" desc="" field="dsm_copernicus2021_30m"/>
    <constraint exp="" desc="" field="lst_summer2026_effective100m"/>
    <constraint exp="" desc="" field="ndwi_summer2026_10m"/>
    <constraint exp="" desc="" field="daily_service_reachable_walk_fraction"/>
    <constraint exp="" desc="" field="research_amenity_priority"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
