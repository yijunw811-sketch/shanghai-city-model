<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshMode="Disabled" simplifyLocal="1" styleCategories="AllStyleCategories" maxScale="0" simplifyDrawingTol="1" simplifyDrawingHints="1" version="3.40.6-Bratislava" hasScaleBasedVisibilityFlag="0" simplifyMaxScale="1" autoRefreshTime="0" simplifyAlgorithm="0" minScale="100000000" symbologyReferenceScale="-1" readOnly="0" labelsEnabled="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endExpression="" startExpression="" durationUnit="min" enabled="0" durationField="" endField="" mode="0" startField="" accumulate="0" limitMode="0" fixedDuration="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" type="IndividualFeatures" binding="Centroid" clamping="Terrain" zoffset="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" extrusionEnabled="0" zscale="1" symbology="Line">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol type="line" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{6b6c4937-87de-4258-806b-f96197811e35}" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="122,2,138,255,hsv:0.81388888888888888,0.98431372549019602,0.54117647058823526,1" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol type="fill" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{026f4f34-424c-4483-b72f-91d62ff0ecc9}" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="122,2,138,255,hsv:0.81388888888888888,0.98431372549019602,0.54117647058823526,1" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="87,2,99,255,hsv:0.81388888888888888,0.98431372549019602,0.38654154268711377,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol type="marker" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{c93365c2-88eb-4036-97e4-d7f7b1654c46}" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="122,2,138,255,hsv:0.81388888888888888,0.98431372549019602,0.54117647058823526,1" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="87,2,99,255,hsv:0.81388888888888888,0.98431372549019602,0.38654154268711377,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="singleSymbol" referencescale="-1" symbollevels="0" enableorderby="0" forceraster="0">
    <symbols>
      <symbol type="fill" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{0e373878-1028-4fe7-a6d8-22564e69cc1a}" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="0,0,0,0,rgb:0,0,0,0" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="143,174,133,255,rgb:0.5607843137254902,0.68235294117647061,0.52156862745098043,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.06" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>0.3</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="provider">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dataset">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source_url">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="retrieved_at">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="release_date">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="license">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="crs_original">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="processing_steps">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="is_inferred">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="evidence">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="confidence">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="spatial_accuracy_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="canonical_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_type">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="snapshot_date">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="access">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags_json">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="green_type">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="interpretation">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="in_aoi">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="provider" index="1" name=""/>
    <alias field="dataset" index="2" name=""/>
    <alias field="source_url" index="3" name=""/>
    <alias field="retrieved_at" index="4" name=""/>
    <alias field="release_date" index="5" name=""/>
    <alias field="license" index="6" name=""/>
    <alias field="crs_original" index="7" name=""/>
    <alias field="processing_steps" index="8" name=""/>
    <alias field="is_inferred" index="9" name=""/>
    <alias field="evidence" index="10" name=""/>
    <alias field="confidence" index="11" name=""/>
    <alias field="spatial_accuracy_m" index="12" name=""/>
    <alias field="canonical_id" index="13" name=""/>
    <alias field="osm_type" index="14" name=""/>
    <alias field="osm_id" index="15" name=""/>
    <alias field="snapshot_date" index="16" name=""/>
    <alias field="name" index="17" name=""/>
    <alias field="access" index="18" name=""/>
    <alias field="tags_json" index="19" name=""/>
    <alias field="green_type" index="20" name=""/>
    <alias field="interpretation" index="21" name=""/>
    <alias field="in_aoi" index="22" name=""/>
  </aliases>
  <splitPolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="provider" policy="Duplicate"/>
    <policy field="dataset" policy="Duplicate"/>
    <policy field="source_url" policy="Duplicate"/>
    <policy field="retrieved_at" policy="Duplicate"/>
    <policy field="release_date" policy="Duplicate"/>
    <policy field="license" policy="Duplicate"/>
    <policy field="crs_original" policy="Duplicate"/>
    <policy field="processing_steps" policy="Duplicate"/>
    <policy field="is_inferred" policy="Duplicate"/>
    <policy field="evidence" policy="Duplicate"/>
    <policy field="confidence" policy="Duplicate"/>
    <policy field="spatial_accuracy_m" policy="Duplicate"/>
    <policy field="canonical_id" policy="Duplicate"/>
    <policy field="osm_type" policy="Duplicate"/>
    <policy field="osm_id" policy="Duplicate"/>
    <policy field="snapshot_date" policy="Duplicate"/>
    <policy field="name" policy="Duplicate"/>
    <policy field="access" policy="Duplicate"/>
    <policy field="tags_json" policy="Duplicate"/>
    <policy field="green_type" policy="Duplicate"/>
    <policy field="interpretation" policy="Duplicate"/>
    <policy field="in_aoi" policy="Duplicate"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="provider" policy="Duplicate"/>
    <policy field="dataset" policy="Duplicate"/>
    <policy field="source_url" policy="Duplicate"/>
    <policy field="retrieved_at" policy="Duplicate"/>
    <policy field="release_date" policy="Duplicate"/>
    <policy field="license" policy="Duplicate"/>
    <policy field="crs_original" policy="Duplicate"/>
    <policy field="processing_steps" policy="Duplicate"/>
    <policy field="is_inferred" policy="Duplicate"/>
    <policy field="evidence" policy="Duplicate"/>
    <policy field="confidence" policy="Duplicate"/>
    <policy field="spatial_accuracy_m" policy="Duplicate"/>
    <policy field="canonical_id" policy="Duplicate"/>
    <policy field="osm_type" policy="Duplicate"/>
    <policy field="osm_id" policy="Duplicate"/>
    <policy field="snapshot_date" policy="Duplicate"/>
    <policy field="name" policy="Duplicate"/>
    <policy field="access" policy="Duplicate"/>
    <policy field="tags_json" policy="Duplicate"/>
    <policy field="green_type" policy="Duplicate"/>
    <policy field="interpretation" policy="Duplicate"/>
    <policy field="in_aoi" policy="Duplicate"/>
  </duplicatePolicies>
  <defaults>
    <default expression="" applyOnUpdate="0" field="fid"/>
    <default expression="" applyOnUpdate="0" field="provider"/>
    <default expression="" applyOnUpdate="0" field="dataset"/>
    <default expression="" applyOnUpdate="0" field="source_url"/>
    <default expression="" applyOnUpdate="0" field="retrieved_at"/>
    <default expression="" applyOnUpdate="0" field="release_date"/>
    <default expression="" applyOnUpdate="0" field="license"/>
    <default expression="" applyOnUpdate="0" field="crs_original"/>
    <default expression="" applyOnUpdate="0" field="processing_steps"/>
    <default expression="" applyOnUpdate="0" field="is_inferred"/>
    <default expression="" applyOnUpdate="0" field="evidence"/>
    <default expression="" applyOnUpdate="0" field="confidence"/>
    <default expression="" applyOnUpdate="0" field="spatial_accuracy_m"/>
    <default expression="" applyOnUpdate="0" field="canonical_id"/>
    <default expression="" applyOnUpdate="0" field="osm_type"/>
    <default expression="" applyOnUpdate="0" field="osm_id"/>
    <default expression="" applyOnUpdate="0" field="snapshot_date"/>
    <default expression="" applyOnUpdate="0" field="name"/>
    <default expression="" applyOnUpdate="0" field="access"/>
    <default expression="" applyOnUpdate="0" field="tags_json"/>
    <default expression="" applyOnUpdate="0" field="green_type"/>
    <default expression="" applyOnUpdate="0" field="interpretation"/>
    <default expression="" applyOnUpdate="0" field="in_aoi"/>
  </defaults>
  <constraints>
    <constraint unique_strength="1" constraints="3" field="fid" notnull_strength="1" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="provider" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="dataset" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="source_url" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="retrieved_at" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="release_date" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="license" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="crs_original" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="processing_steps" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="is_inferred" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="evidence" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="confidence" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="spatial_accuracy_m" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="canonical_id" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="osm_type" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="osm_id" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="snapshot_date" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="name" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="access" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="tags_json" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="green_type" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="interpretation" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="in_aoi" notnull_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="provider"/>
    <constraint exp="" desc="" field="dataset"/>
    <constraint exp="" desc="" field="source_url"/>
    <constraint exp="" desc="" field="retrieved_at"/>
    <constraint exp="" desc="" field="release_date"/>
    <constraint exp="" desc="" field="license"/>
    <constraint exp="" desc="" field="crs_original"/>
    <constraint exp="" desc="" field="processing_steps"/>
    <constraint exp="" desc="" field="is_inferred"/>
    <constraint exp="" desc="" field="evidence"/>
    <constraint exp="" desc="" field="confidence"/>
    <constraint exp="" desc="" field="spatial_accuracy_m"/>
    <constraint exp="" desc="" field="canonical_id"/>
    <constraint exp="" desc="" field="osm_type"/>
    <constraint exp="" desc="" field="osm_id"/>
    <constraint exp="" desc="" field="snapshot_date"/>
    <constraint exp="" desc="" field="name"/>
    <constraint exp="" desc="" field="access"/>
    <constraint exp="" desc="" field="tags_json"/>
    <constraint exp="" desc="" field="green_type"/>
    <constraint exp="" desc="" field="interpretation"/>
    <constraint exp="" desc="" field="in_aoi"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
