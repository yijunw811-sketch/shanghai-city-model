<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshMode="Disabled" simplifyLocal="1" styleCategories="AllStyleCategories" maxScale="0" simplifyDrawingTol="1" simplifyDrawingHints="1" version="3.40.6-Bratislava" hasScaleBasedVisibilityFlag="0" simplifyMaxScale="1" autoRefreshTime="0" simplifyAlgorithm="0" minScale="100000000" symbologyReferenceScale="-1" readOnly="0" labelsEnabled="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endExpression="" startExpression="" durationUnit="min" enabled="0" durationField="" endField="" mode="0" startField="" accumulate="0" limitMode="0" fixedDuration="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" type="IndividualFeatures" binding="Centroid" clamping="Terrain" zoffset="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" extrusionEnabled="0" zscale="1" symbology="Line">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol type="line" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{ac9b058a-fddd-4da8-8def-371d29d95b4d}" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="248,222,155,255,hsv:0.11944444444444445,0.37647058823529411,0.97254901960784312,1" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol type="fill" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{e1d6aaad-381c-4ce1-85ca-483bbc496d16}" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="248,222,155,255,hsv:0.11944444444444445,0.37647058823529411,0.97254901960784312,1" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="177,158,110,255,hsv:0.11944444444444445,0.37647058823529411,0.69466697184710458,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol type="marker" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{d3f07a27-207d-4afb-af4e-ac71a6f44a07}" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="248,222,155,255,hsv:0.11944444444444445,0.37647058823529411,0.97254901960784312,1" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="177,158,110,255,hsv:0.11944444444444445,0.37647058823529411,0.69466697184710458,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="singleSymbol" referencescale="-1" symbollevels="0" enableorderby="0" forceraster="0">
    <symbols>
      <symbol type="line" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{c7f508c9-f260-4d64-95b7-5fe4124525b8}" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="36,70,91,255,rgb:0.14117647058823529,0.27450980392156865,0.35686274509803922,1" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.06" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>0.4</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="way_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="u">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="v">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="segment_index">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="highway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="length_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="walk">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cycle">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="vehicle">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="layer">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="bridge">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tunnel">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="oneway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="width">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="lanes">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="sidewalk">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="cycleway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="foot">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="bicycle">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="access">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="wheelchair">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="surface">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source_url">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="license">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="access_method">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="in_aoi">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="way_id" index="1" name=""/>
    <alias field="u" index="2" name=""/>
    <alias field="v" index="3" name=""/>
    <alias field="segment_index" index="4" name=""/>
    <alias field="highway" index="5" name=""/>
    <alias field="name" index="6" name=""/>
    <alias field="length_m" index="7" name=""/>
    <alias field="walk" index="8" name=""/>
    <alias field="cycle" index="9" name=""/>
    <alias field="vehicle" index="10" name=""/>
    <alias field="layer" index="11" name=""/>
    <alias field="bridge" index="12" name=""/>
    <alias field="tunnel" index="13" name=""/>
    <alias field="oneway" index="14" name=""/>
    <alias field="width" index="15" name=""/>
    <alias field="lanes" index="16" name=""/>
    <alias field="sidewalk" index="17" name=""/>
    <alias field="cycleway" index="18" name=""/>
    <alias field="foot" index="19" name=""/>
    <alias field="bicycle" index="20" name=""/>
    <alias field="access" index="21" name=""/>
    <alias field="wheelchair" index="22" name=""/>
    <alias field="surface" index="23" name=""/>
    <alias field="source_url" index="24" name=""/>
    <alias field="license" index="25" name=""/>
    <alias field="access_method" index="26" name=""/>
    <alias field="in_aoi" index="27" name=""/>
  </aliases>
  <splitPolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="way_id" policy="Duplicate"/>
    <policy field="u" policy="Duplicate"/>
    <policy field="v" policy="Duplicate"/>
    <policy field="segment_index" policy="Duplicate"/>
    <policy field="highway" policy="Duplicate"/>
    <policy field="name" policy="Duplicate"/>
    <policy field="length_m" policy="Duplicate"/>
    <policy field="walk" policy="Duplicate"/>
    <policy field="cycle" policy="Duplicate"/>
    <policy field="vehicle" policy="Duplicate"/>
    <policy field="layer" policy="Duplicate"/>
    <policy field="bridge" policy="Duplicate"/>
    <policy field="tunnel" policy="Duplicate"/>
    <policy field="oneway" policy="Duplicate"/>
    <policy field="width" policy="Duplicate"/>
    <policy field="lanes" policy="Duplicate"/>
    <policy field="sidewalk" policy="Duplicate"/>
    <policy field="cycleway" policy="Duplicate"/>
    <policy field="foot" policy="Duplicate"/>
    <policy field="bicycle" policy="Duplicate"/>
    <policy field="access" policy="Duplicate"/>
    <policy field="wheelchair" policy="Duplicate"/>
    <policy field="surface" policy="Duplicate"/>
    <policy field="source_url" policy="Duplicate"/>
    <policy field="license" policy="Duplicate"/>
    <policy field="access_method" policy="Duplicate"/>
    <policy field="in_aoi" policy="Duplicate"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="way_id" policy="Duplicate"/>
    <policy field="u" policy="Duplicate"/>
    <policy field="v" policy="Duplicate"/>
    <policy field="segment_index" policy="Duplicate"/>
    <policy field="highway" policy="Duplicate"/>
    <policy field="name" policy="Duplicate"/>
    <policy field="length_m" policy="Duplicate"/>
    <policy field="walk" policy="Duplicate"/>
    <policy field="cycle" policy="Duplicate"/>
    <policy field="vehicle" policy="Duplicate"/>
    <policy field="layer" policy="Duplicate"/>
    <policy field="bridge" policy="Duplicate"/>
    <policy field="tunnel" policy="Duplicate"/>
    <policy field="oneway" policy="Duplicate"/>
    <policy field="width" policy="Duplicate"/>
    <policy field="lanes" policy="Duplicate"/>
    <policy field="sidewalk" policy="Duplicate"/>
    <policy field="cycleway" policy="Duplicate"/>
    <policy field="foot" policy="Duplicate"/>
    <policy field="bicycle" policy="Duplicate"/>
    <policy field="access" policy="Duplicate"/>
    <policy field="wheelchair" policy="Duplicate"/>
    <policy field="surface" policy="Duplicate"/>
    <policy field="source_url" policy="Duplicate"/>
    <policy field="license" policy="Duplicate"/>
    <policy field="access_method" policy="Duplicate"/>
    <policy field="in_aoi" policy="Duplicate"/>
  </duplicatePolicies>
  <defaults>
    <default expression="" applyOnUpdate="0" field="fid"/>
    <default expression="" applyOnUpdate="0" field="way_id"/>
    <default expression="" applyOnUpdate="0" field="u"/>
    <default expression="" applyOnUpdate="0" field="v"/>
    <default expression="" applyOnUpdate="0" field="segment_index"/>
    <default expression="" applyOnUpdate="0" field="highway"/>
    <default expression="" applyOnUpdate="0" field="name"/>
    <default expression="" applyOnUpdate="0" field="length_m"/>
    <default expression="" applyOnUpdate="0" field="walk"/>
    <default expression="" applyOnUpdate="0" field="cycle"/>
    <default expression="" applyOnUpdate="0" field="vehicle"/>
    <default expression="" applyOnUpdate="0" field="layer"/>
    <default expression="" applyOnUpdate="0" field="bridge"/>
    <default expression="" applyOnUpdate="0" field="tunnel"/>
    <default expression="" applyOnUpdate="0" field="oneway"/>
    <default expression="" applyOnUpdate="0" field="width"/>
    <default expression="" applyOnUpdate="0" field="lanes"/>
    <default expression="" applyOnUpdate="0" field="sidewalk"/>
    <default expression="" applyOnUpdate="0" field="cycleway"/>
    <default expression="" applyOnUpdate="0" field="foot"/>
    <default expression="" applyOnUpdate="0" field="bicycle"/>
    <default expression="" applyOnUpdate="0" field="access"/>
    <default expression="" applyOnUpdate="0" field="wheelchair"/>
    <default expression="" applyOnUpdate="0" field="surface"/>
    <default expression="" applyOnUpdate="0" field="source_url"/>
    <default expression="" applyOnUpdate="0" field="license"/>
    <default expression="" applyOnUpdate="0" field="access_method"/>
    <default expression="" applyOnUpdate="0" field="in_aoi"/>
  </defaults>
  <constraints>
    <constraint unique_strength="1" constraints="3" field="fid" notnull_strength="1" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="way_id" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="u" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="v" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="segment_index" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="highway" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="name" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="length_m" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="walk" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="cycle" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="vehicle" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="layer" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="bridge" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="tunnel" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="oneway" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="width" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="lanes" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="sidewalk" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="cycleway" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="foot" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="bicycle" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="access" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="wheelchair" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="surface" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="source_url" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="license" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="access_method" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="in_aoi" notnull_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="way_id"/>
    <constraint exp="" desc="" field="u"/>
    <constraint exp="" desc="" field="v"/>
    <constraint exp="" desc="" field="segment_index"/>
    <constraint exp="" desc="" field="highway"/>
    <constraint exp="" desc="" field="name"/>
    <constraint exp="" desc="" field="length_m"/>
    <constraint exp="" desc="" field="walk"/>
    <constraint exp="" desc="" field="cycle"/>
    <constraint exp="" desc="" field="vehicle"/>
    <constraint exp="" desc="" field="layer"/>
    <constraint exp="" desc="" field="bridge"/>
    <constraint exp="" desc="" field="tunnel"/>
    <constraint exp="" desc="" field="oneway"/>
    <constraint exp="" desc="" field="width"/>
    <constraint exp="" desc="" field="lanes"/>
    <constraint exp="" desc="" field="sidewalk"/>
    <constraint exp="" desc="" field="cycleway"/>
    <constraint exp="" desc="" field="foot"/>
    <constraint exp="" desc="" field="bicycle"/>
    <constraint exp="" desc="" field="access"/>
    <constraint exp="" desc="" field="wheelchair"/>
    <constraint exp="" desc="" field="surface"/>
    <constraint exp="" desc="" field="source_url"/>
    <constraint exp="" desc="" field="license"/>
    <constraint exp="" desc="" field="access_method"/>
    <constraint exp="" desc="" field="in_aoi"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>
