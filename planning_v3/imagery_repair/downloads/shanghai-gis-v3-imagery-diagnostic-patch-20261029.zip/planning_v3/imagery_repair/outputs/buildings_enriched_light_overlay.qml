<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis autoRefreshMode="Disabled" simplifyLocal="1" styleCategories="AllStyleCategories" maxScale="0" simplifyDrawingTol="1" simplifyDrawingHints="1" version="3.40.6-Bratislava" hasScaleBasedVisibilityFlag="0" simplifyMaxScale="1" autoRefreshTime="0" simplifyAlgorithm="0" minScale="100000000" symbologyReferenceScale="-1" readOnly="0" labelsEnabled="0">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endExpression="" startExpression="" durationUnit="min" enabled="0" durationField="" endField="" mode="0" startField="" accumulate="0" limitMode="0" fixedDuration="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation extrusion="0" type="IndividualFeatures" binding="Centroid" clamping="Terrain" zoffset="0" respectLayerSymbol="1" showMarkerSymbolInSurfacePlots="0" extrusionEnabled="0" zscale="1" symbology="Line">
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol type="line" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{5ac28ea4-100a-4cd5-8240-068f94b3dede}" pass="0" class="SimpleLine">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="138,98,109,255,hsv:0.95277777777777772,0.29019607843137257,0.54117647058823526,1" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.6" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol type="fill" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{f44fce03-5451-4949-8d05-3fbfdd67d1a6}" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="138,98,109,255,hsv:0.95277777777777772,0.29019607843137257,0.54117647058823526,1" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="99,70,78,255,hsv:0.95277777777777772,0.29019607843137257,0.38654154268711377,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol type="marker" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{a8cba0ed-f829-462a-b51e-4251d001d89c}" pass="0" class="SimpleMarker">
          <Option type="Map">
            <Option type="QString" value="0" name="angle"/>
            <Option type="QString" value="square" name="cap_style"/>
            <Option type="QString" value="138,98,109,255,hsv:0.95277777777777772,0.29019607843137257,0.54117647058823526,1" name="color"/>
            <Option type="QString" value="1" name="horizontal_anchor_point"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="diamond" name="name"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="99,70,78,255,hsv:0.95277777777777772,0.29019607843137257,0.38654154268711377,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.2" name="outline_width"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="diameter" name="scale_method"/>
            <Option type="QString" value="3" name="size"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
            <Option type="QString" value="MM" name="size_unit"/>
            <Option type="QString" value="1" name="vertical_anchor_point"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 type="singleSymbol" referencescale="-1" symbollevels="0" enableorderby="0" forceraster="0">
    <symbols>
      <symbol type="fill" force_rhr="0" is_animated="0" clip_to_extent="1" alpha="1" frame_rate="10" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" id="{e1f84e7d-4459-4f47-8987-afcdf2bf24ef}" pass="0" class="SimpleFill">
          <Option type="Map">
            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
            <Option type="QString" value="0,0,0,0,rgb:0,0,0,0" name="color"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="231,238,230,255,rgb:0.90588235294117647,0.93333333333333335,0.90196078431372551,1" name="outline_color"/>
            <Option type="QString" value="solid" name="outline_style"/>
            <Option type="QString" value="0.05" name="outline_width"/>
            <Option type="QString" value="MM" name="outline_width_unit"/>
            <Option type="QString" value="solid" name="style"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <rotation/>
    <sizescale/>
    <data-defined-properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>0.25</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks type="StringList">
      <Option type="QString" value=""/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source_date">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="license">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_type">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tags_json">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="part">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="min_height_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_source">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="confidence">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="overture_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="feature_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="upstream_dataset">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_explanation">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="context_landuse">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="footprint_removed_fraction">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="model_precision_grid_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="provider">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="dataset">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="source_url">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="retrieved_at">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="release_date">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="crs_original">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="processing_steps">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="is_inferred">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="evidence">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="spatial_accuracy_m">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="footprint_m2">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_is_measured">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_quality">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="height_class">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="longitude">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="latitude">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="coordinate_meaning">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" index="0" name=""/>
    <alias field="source" index="1" name=""/>
    <alias field="source_date" index="2" name=""/>
    <alias field="license" index="3" name=""/>
    <alias field="osm_type" index="4" name=""/>
    <alias field="osm_id" index="5" name=""/>
    <alias field="name" index="6" name=""/>
    <alias field="tags_json" index="7" name=""/>
    <alias field="part" index="8" name=""/>
    <alias field="building" index="9" name=""/>
    <alias field="height_m" index="10" name=""/>
    <alias field="min_height_m" index="11" name=""/>
    <alias field="height_source" index="12" name=""/>
    <alias field="confidence" index="13" name=""/>
    <alias field="overture_id" index="14" name=""/>
    <alias field="feature_id" index="15" name=""/>
    <alias field="upstream_dataset" index="16" name=""/>
    <alias field="height_explanation" index="17" name=""/>
    <alias field="context_landuse" index="18" name=""/>
    <alias field="footprint_removed_fraction" index="19" name=""/>
    <alias field="model_precision_grid_m" index="20" name=""/>
    <alias field="provider" index="21" name=""/>
    <alias field="dataset" index="22" name=""/>
    <alias field="source_url" index="23" name=""/>
    <alias field="retrieved_at" index="24" name=""/>
    <alias field="release_date" index="25" name=""/>
    <alias field="crs_original" index="26" name=""/>
    <alias field="processing_steps" index="27" name=""/>
    <alias field="is_inferred" index="28" name=""/>
    <alias field="evidence" index="29" name=""/>
    <alias field="spatial_accuracy_m" index="30" name=""/>
    <alias field="footprint_m2" index="31" name=""/>
    <alias field="height_is_measured" index="32" name=""/>
    <alias field="height_quality" index="33" name=""/>
    <alias field="height_class" index="34" name=""/>
    <alias field="longitude" index="35" name=""/>
    <alias field="latitude" index="36" name=""/>
    <alias field="coordinate_meaning" index="37" name=""/>
  </aliases>
  <splitPolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="source" policy="Duplicate"/>
    <policy field="source_date" policy="Duplicate"/>
    <policy field="license" policy="Duplicate"/>
    <policy field="osm_type" policy="Duplicate"/>
    <policy field="osm_id" policy="Duplicate"/>
    <policy field="name" policy="Duplicate"/>
    <policy field="tags_json" policy="Duplicate"/>
    <policy field="part" policy="Duplicate"/>
    <policy field="building" policy="Duplicate"/>
    <policy field="height_m" policy="Duplicate"/>
    <policy field="min_height_m" policy="Duplicate"/>
    <policy field="height_source" policy="Duplicate"/>
    <policy field="confidence" policy="Duplicate"/>
    <policy field="overture_id" policy="Duplicate"/>
    <policy field="feature_id" policy="Duplicate"/>
    <policy field="upstream_dataset" policy="Duplicate"/>
    <policy field="height_explanation" policy="Duplicate"/>
    <policy field="context_landuse" policy="Duplicate"/>
    <policy field="footprint_removed_fraction" policy="Duplicate"/>
    <policy field="model_precision_grid_m" policy="Duplicate"/>
    <policy field="provider" policy="Duplicate"/>
    <policy field="dataset" policy="Duplicate"/>
    <policy field="source_url" policy="Duplicate"/>
    <policy field="retrieved_at" policy="Duplicate"/>
    <policy field="release_date" policy="Duplicate"/>
    <policy field="crs_original" policy="Duplicate"/>
    <policy field="processing_steps" policy="Duplicate"/>
    <policy field="is_inferred" policy="Duplicate"/>
    <policy field="evidence" policy="Duplicate"/>
    <policy field="spatial_accuracy_m" policy="Duplicate"/>
    <policy field="footprint_m2" policy="Duplicate"/>
    <policy field="height_is_measured" policy="Duplicate"/>
    <policy field="height_quality" policy="Duplicate"/>
    <policy field="height_class" policy="Duplicate"/>
    <policy field="longitude" policy="Duplicate"/>
    <policy field="latitude" policy="Duplicate"/>
    <policy field="coordinate_meaning" policy="Duplicate"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy field="fid" policy="Duplicate"/>
    <policy field="source" policy="Duplicate"/>
    <policy field="source_date" policy="Duplicate"/>
    <policy field="license" policy="Duplicate"/>
    <policy field="osm_type" policy="Duplicate"/>
    <policy field="osm_id" policy="Duplicate"/>
    <policy field="name" policy="Duplicate"/>
    <policy field="tags_json" policy="Duplicate"/>
    <policy field="part" policy="Duplicate"/>
    <policy field="building" policy="Duplicate"/>
    <policy field="height_m" policy="Duplicate"/>
    <policy field="min_height_m" policy="Duplicate"/>
    <policy field="height_source" policy="Duplicate"/>
    <policy field="confidence" policy="Duplicate"/>
    <policy field="overture_id" policy="Duplicate"/>
    <policy field="feature_id" policy="Duplicate"/>
    <policy field="upstream_dataset" policy="Duplicate"/>
    <policy field="height_explanation" policy="Duplicate"/>
    <policy field="context_landuse" policy="Duplicate"/>
    <policy field="footprint_removed_fraction" policy="Duplicate"/>
    <policy field="model_precision_grid_m" policy="Duplicate"/>
    <policy field="provider" policy="Duplicate"/>
    <policy field="dataset" policy="Duplicate"/>
    <policy field="source_url" policy="Duplicate"/>
    <policy field="retrieved_at" policy="Duplicate"/>
    <policy field="release_date" policy="Duplicate"/>
    <policy field="crs_original" policy="Duplicate"/>
    <policy field="processing_steps" policy="Duplicate"/>
    <policy field="is_inferred" policy="Duplicate"/>
    <policy field="evidence" policy="Duplicate"/>
    <policy field="spatial_accuracy_m" policy="Duplicate"/>
    <policy field="footprint_m2" policy="Duplicate"/>
    <policy field="height_is_measured" policy="Duplicate"/>
    <policy field="height_quality" policy="Duplicate"/>
    <policy field="height_class" policy="Duplicate"/>
    <policy field="longitude" policy="Duplicate"/>
    <policy field="latitude" policy="Duplicate"/>
    <policy field="coordinate_meaning" policy="Duplicate"/>
  </duplicatePolicies>
  <defaults>
    <default expression="" applyOnUpdate="0" field="fid"/>
    <default expression="" applyOnUpdate="0" field="source"/>
    <default expression="" applyOnUpdate="0" field="source_date"/>
    <default expression="" applyOnUpdate="0" field="license"/>
    <default expression="" applyOnUpdate="0" field="osm_type"/>
    <default expression="" applyOnUpdate="0" field="osm_id"/>
    <default expression="" applyOnUpdate="0" field="name"/>
    <default expression="" applyOnUpdate="0" field="tags_json"/>
    <default expression="" applyOnUpdate="0" field="part"/>
    <default expression="" applyOnUpdate="0" field="building"/>
    <default expression="" applyOnUpdate="0" field="height_m"/>
    <default expression="" applyOnUpdate="0" field="min_height_m"/>
    <default expression="" applyOnUpdate="0" field="height_source"/>
    <default expression="" applyOnUpdate="0" field="confidence"/>
    <default expression="" applyOnUpdate="0" field="overture_id"/>
    <default expression="" applyOnUpdate="0" field="feature_id"/>
    <default expression="" applyOnUpdate="0" field="upstream_dataset"/>
    <default expression="" applyOnUpdate="0" field="height_explanation"/>
    <default expression="" applyOnUpdate="0" field="context_landuse"/>
    <default expression="" applyOnUpdate="0" field="footprint_removed_fraction"/>
    <default expression="" applyOnUpdate="0" field="model_precision_grid_m"/>
    <default expression="" applyOnUpdate="0" field="provider"/>
    <default expression="" applyOnUpdate="0" field="dataset"/>
    <default expression="" applyOnUpdate="0" field="source_url"/>
    <default expression="" applyOnUpdate="0" field="retrieved_at"/>
    <default expression="" applyOnUpdate="0" field="release_date"/>
    <default expression="" applyOnUpdate="0" field="crs_original"/>
    <default expression="" applyOnUpdate="0" field="processing_steps"/>
    <default expression="" applyOnUpdate="0" field="is_inferred"/>
    <default expression="" applyOnUpdate="0" field="evidence"/>
    <default expression="" applyOnUpdate="0" field="spatial_accuracy_m"/>
    <default expression="" applyOnUpdate="0" field="footprint_m2"/>
    <default expression="" applyOnUpdate="0" field="height_is_measured"/>
    <default expression="" applyOnUpdate="0" field="height_quality"/>
    <default expression="" applyOnUpdate="0" field="height_class"/>
    <default expression="" applyOnUpdate="0" field="longitude"/>
    <default expression="" applyOnUpdate="0" field="latitude"/>
    <default expression="" applyOnUpdate="0" field="coordinate_meaning"/>
  </defaults>
  <constraints>
    <constraint unique_strength="1" constraints="3" field="fid" notnull_strength="1" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="source" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="source_date" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="license" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="osm_type" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="osm_id" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="name" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="tags_json" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="part" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="building" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="height_m" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="min_height_m" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="height_source" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="confidence" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="overture_id" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="feature_id" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="upstream_dataset" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="height_explanation" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="context_landuse" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="footprint_removed_fraction" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="model_precision_grid_m" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="provider" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="dataset" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="source_url" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="retrieved_at" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="release_date" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="crs_original" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="processing_steps" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="is_inferred" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="evidence" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="spatial_accuracy_m" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="footprint_m2" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="height_is_measured" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="height_quality" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="height_class" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="longitude" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="latitude" notnull_strength="0" exp_strength="0"/>
    <constraint unique_strength="0" constraints="0" field="coordinate_meaning" notnull_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="source"/>
    <constraint exp="" desc="" field="source_date"/>
    <constraint exp="" desc="" field="license"/>
    <constraint exp="" desc="" field="osm_type"/>
    <constraint exp="" desc="" field="osm_id"/>
    <constraint exp="" desc="" field="name"/>
    <constraint exp="" desc="" field="tags_json"/>
    <constraint exp="" desc="" field="part"/>
    <constraint exp="" desc="" field="building"/>
    <constraint exp="" desc="" field="height_m"/>
    <constraint exp="" desc="" field="min_height_m"/>
    <constraint exp="" desc="" field="height_source"/>
    <constraint exp="" desc="" field="confidence"/>
    <constraint exp="" desc="" field="overture_id"/>
    <constraint exp="" desc="" field="feature_id"/>
    <constraint exp="" desc="" field="upstream_dataset"/>
    <constraint exp="" desc="" field="height_explanation"/>
    <constraint exp="" desc="" field="context_landuse"/>
    <constraint exp="" desc="" field="footprint_removed_fraction"/>
    <constraint exp="" desc="" field="model_precision_grid_m"/>
    <constraint exp="" desc="" field="provider"/>
    <constraint exp="" desc="" field="dataset"/>
    <constraint exp="" desc="" field="source_url"/>
    <constraint exp="" desc="" field="retrieved_at"/>
    <constraint exp="" desc="" field="release_date"/>
    <constraint exp="" desc="" field="crs_original"/>
    <constraint exp="" desc="" field="processing_steps"/>
    <constraint exp="" desc="" field="is_inferred"/>
    <constraint exp="" desc="" field="evidence"/>
    <constraint exp="" desc="" field="spatial_accuracy_m"/>
    <constraint exp="" desc="" field="footprint_m2"/>
    <constraint exp="" desc="" field="height_is_measured"/>
    <constraint exp="" desc="" field="height_quality"/>
    <constraint exp="" desc="" field="height_class"/>
    <constraint exp="" desc="" field="longitude"/>
    <constraint exp="" desc="" field="latitude"/>
    <constraint exp="" desc="" field="coordinate_meaning"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig sortOrder="0" sortExpression="" actionWidgetStyle="dropDown">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
